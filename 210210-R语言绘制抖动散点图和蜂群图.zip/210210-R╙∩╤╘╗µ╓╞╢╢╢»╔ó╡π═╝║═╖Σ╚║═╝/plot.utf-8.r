#示例数据，详情加载 multcomp 包后 ?cholesterol
data(cholesterol, package = 'multcomp')
head(cholesterol)
levels(cholesterol$trt)

#常规散点图，使用 geom_point()
library(ggplot2)

p <- ggplot(cholesterol, aes(x = trt, y = response, color = trt)) +
geom_point(size = 1.5, show.legend = FALSE) +  #普通散点图
scale_color_manual(values = c('#EA5C15', '#EEE938', '#E61F18', '#69B72A', '#002D8E')) +  #颜色自定义赋值
theme(panel.grid = element_blank(), panel.background = element_blank(), 
    axis.line = element_line(color = 'black')) +  #去除默认的背景色、边框等
labs(x = 'Treat', y = 'Response') + #坐标轴标签
stat_summary(fun.y = mean, fun.ymin = mean, fun.ymax = mean, 
    geom = 'crossbar', width = 0.3, size = 0.3, color = 'black') +  #计算各组均值并添加在图中
stat_summary(fun.data = function(x) median_hilow(x, 0.5), 
    geom = 'errorbar', width = 0.25, size = 0.2, color = 'black')  #计算各组标准差并添加在图中

p

#抖动点图，使用 geom_jitter()，或者 geom_point(position='jitter')
library(ggplot2)

p <- ggplot(cholesterol, aes(x = trt, y = response, color = trt)) +
geom_jitter(size = 1.5, width = 0.2, show.legend = FALSE) +  #直接使用该函数绘制抖动点
#geom_point(position = 'jitter', size = 1.5, show.legend = FALSE) +  #或者在散点图中添加随机的抖动效果
scale_color_manual(values = c('#EA5C15', '#EEE938', '#E61F18', '#69B72A', '#002D8E')) +  #颜色自定义赋值
theme(panel.grid = element_blank(), panel.background = element_blank(), 
    axis.line = element_line(color = 'black')) +  #去除默认的背景色、边框等
labs(x = 'Treat', y = 'Response') + #坐标轴标签
stat_summary(fun.y = mean, fun.ymin = mean, fun.ymax = mean, 
    geom = 'crossbar', width = 0.3, size = 0.3, color = 'black') +  #计算各组均值并添加在图中
stat_summary(fun.data = function(x) median_hilow(x, 0.5), 
    geom = 'errorbar', width = 0.25, size = 0.2, color = 'black')  #计算各组标准差并添加在图中

p

#蜂群图，使用 ggbeeswarm 包函数 geom_beeswarm()
library(ggplot2)
library(ggbeeswarm)

p <- ggplot(cholesterol, aes(x = trt, y = response, color = trt)) +
geom_beeswarm(cex = 1.5, show.legend = FALSE) +  #蜂群图
scale_color_manual(values = c('#EA5C15', '#EEE938', '#E61F18', '#69B72A', '#002D8E')) +  #颜色自定义赋值
theme(panel.grid = element_blank(), panel.background = element_blank(), 
    axis.line = element_line(color = 'black')) +  #去除默认的背景色、边框等
labs(x = 'Treat', y = 'Response') + #坐标轴标签
stat_summary(fun.y = mean, fun.ymin = mean, fun.ymax = mean, 
    geom = 'crossbar', width = 0.3, size = 0.3, color = 'black') +  #计算各组均值并添加在图中
stat_summary(fun.data = function(x) median_hilow(x, 0.5), 
    geom = 'errorbar', width = 0.25, size = 0.2, color = 'black')  #计算各组标准差并添加在图中

p

#箱线图带抖动散点
ggplot(cholesterol, aes(x = trt, y = response, color = trt)) +
geom_boxplot(width = 0.5) +  #箱线图
geom_jitter(size = 1.5, width = 0.2) +  #添加抖动点
scale_color_manual(values = c('#EA5C15', '#EEE938', '#E61F18', '#69B72A', '#002D8E')) +  #颜色自定义赋值
theme(panel.grid = element_blank(), panel.background = element_blank(), 
    axis.line = element_line(color = 'black'), legend.position = 'none') +  #去除默认的背景色、边框等
labs(x = 'Treat', y = 'Response')

#均值的柱形图带抖动散点
ggplot(cholesterol, aes(x = trt, y = response, color = trt)) +
stat_summary(fun.y = mean, fun.ymin = mean, fun.ymax = mean, 
    geom = 'bar', width = 0.3, size = 0.3, fill = 'transparents') +  #各组均值的柱形图
stat_summary(fun.data = function(x) median_hilow(x, 0.5), 
    geom = 'errorbar', width = 0.25, size = 0.2) +  #计算各组标准差并添加在图中
geom_jitter(size = 1.5, width = 0.2) +  #添加抖动点
scale_color_manual(values = c('#EA5C15', '#EEE938', '#E61F18', '#69B72A', '#002D8E')) +  #颜色自定义赋值
theme(panel.grid = element_blank(), panel.background = element_blank(), 
    axis.line = element_line(color = 'black'), legend.position = 'none') +  #去除默认的背景色、边框等
labs(x = 'Treat', y = 'Response') +  #坐标轴标签
scale_y_continuous(expand = c(0, 0), limits = c(0, max(cholesterol$response)+3))  #让柱形图底端对齐 x 轴

