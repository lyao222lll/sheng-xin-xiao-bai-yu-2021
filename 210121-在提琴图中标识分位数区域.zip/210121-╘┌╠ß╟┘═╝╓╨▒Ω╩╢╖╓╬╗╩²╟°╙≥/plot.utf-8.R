#示例数据集，可加载 ggridges 包后 ?lincoln_weather 查看概要
data(lincoln_weather, package = 'ggridges')
View(lincoln_weather)

##使用 ggplot2 绘制箱线图或提琴图，展示每个月份的日平均气温的分布
#选择数据便于作图
dat <- data.frame(lincoln_weather[c('Month', 'Mean Temperature [F]')])
names(dat) <- c('Month', 'Mean_Temperature')
dat$Month <- factor(dat$Month, levels = rev(levels(dat$Month)))

#如下是一个简单的提琴图示例
library(ggplot2) 

p <- ggplot(dat, aes(x = Month, y = Mean_Temperature)) +
coord_flip() +
theme(panel.grid = element_blank(), panel.background = element_blank(), 
    axis.line = element_line(color = 'black')) +
labs(x = 'Month', y = 'Mean Temperature (℉)') +
geom_violin(fill = '#ADC6E1', size = 0.5)

p

#可以在提琴图上方叠加一个小箱线图，额外指示分位数信息
p +
geom_boxplot(fill = 'white', outlier.size = 0.5, width = 0.15, size = 0.3)

#尝试在提琴图中添加填充阴影指示分位数
#参考自：https://stackoverflow.com/questions/22278951/combining-violin-plot-with-box-plot
library(dplyr)

coords <- ggplot_build(p)$data        # use ggbuild to get the outline co-ords
d <- coords[[1]]                      # this gets the df in a usable form
groups <- unique(d$group)             # get the unique 'violin' ids

# function to create geom_ploygon calls
fill_viol <- function(data, val_x, val_y, v, gr) {
    quants <- mutate(v, x.l = x-violinwidth/2, x.r = x+violinwidth/2, cuts = cut(y, quantile(data[as.numeric(data[[val_x]])==gr,val_y])))  # add 1/2 width each way to each x value
    plotquants <- data.frame(
        x = c(quants$x.l, rev(quants$x.r)),      # left x bottom to top, then right x top to bottom
        y = c(quants$y, rev(quants$y)),          # double up the y values to match
        id = c(quants$cuts, rev(quants$cuts))    # cut by quantile to create polygon id
    )
    geom_polygon(aes(x, y, fill = as.factor(id)), data = plotquants)    # return the geom_ploygon object
}

# plot
p +
lapply(groups, function(x) fill_viol(data = dat, val_x = 'Month', val_y = 'Mean_Temperature', v = d[d$group==x, ], gr = x)) +    # plus polygon objects for each violin
scale_fill_brewer(palette = 'Reds', name = 'Quantile\n', labels = c('25','50','75','100'))    # plus fill
