##读取示例数据集，如上述所示的基因表达矩阵
dat <- read.delim('gene.txt', sep = '\t', row.names = 1)

#不同基因表达值的数量级差距挺大的，推荐做个标准化（如 z-score）或其它合适的转化（如 log 转化），利于后续稳健地聚类
dat_scale <- as.matrix(log2(dat))

##训练 SOM
library(kohonen)

#初始化神经网络节点的拓扑关系，详情 ?somgrid
#例如这里指定了 10×10 的二维矩形网格节点，实际情况中您需要根据数据特点指定合适的规模，以及选择使用矩形还是六边形网格
som_grid <- somgrid(xdim = 10, ydim = 10, topo = 'rectangular')  

#SOM 分析，对基因分配节点，详情 ?supersom
#例如这里指定了 100 次的迭代计算，实际情况中需要视情况变更
set.seed(123)
som_model <- supersom(dat_scale, grid = som_grid, rlen = 100)

##一些可视化功能，以及对 SOM 质量的评估
#用于评估 SOM 迭代次数是否足够，详情 ?plot.kohonen
plot(som_model, type = 'changes')

#计量每个SOM中心点包含的基因的数目，详情 ?plot.kohonen
plot(som_model, type = 'count')

#查看邻居距离，评估潜在边界点，详情 ?plot.kohonen
plot(som_model, type = 'dist.neighbours')

#查看权重向量的分布模式，详情 ?plot.kohonen
plot(som_model, type = 'codes')

#各个网格节点中，可视为划分到该节点中的基因表达水平的热图，详情 ?plot.kohonen
coolBlueHotRed <- function(n, alpha = 0.7) rainbow(n, end=4/6, alpha=alpha)[n:1]

color_by <- apply(som_model$data[[1]], 1, mean)
unit_colors <- aggregate(color_by, by = list(som_model$unit.classif), FUN = mean, simplify = TRUE)
unit_dat <- data.frame(value = rep(0, 100))
unit_dat[unit_colors$Group.1,'value'] <- unit_colors$x

plot(som_model, type = 'property', property = unit_dat[[1]], palette.name = coolBlueHotRed, 
    shape = 'round', keepMargins = TRUE, border = NA)

plot(som_model, type = 'property', property = unit_dat[[1]], palette.name = coolBlueHotRed, 
    shape = 'straight', keepMargins = TRUE, border = NA)

#定位目标网格节点在映射图中的位置
som_model$grid

#获取每个 SOM 中心点相关的基因
som_model_class <- data.frame(gene_name = rownames(som_model$data[[1]]), code_class = som_model$unit.classif)
som_model_class <- cbind(som_model_class, dat)
head(som_model_class)  #包括基因名称，所属的网格节点编号，以及表达值信息

#输出 SOM 结果
#write.table(som_model_class, 'gene_SOM.txt', row.names = FALSE, sep = '\t', quote = FALSE)



plotSOM(som_model)

#例如，进一步在整体映射图中划分 5 个聚类模块
groups = 3
hc <- cutree(hclust(dist(som_model$codes)), groups)

plot(som_model, type = 'property', bgcol = rainbow(groups)[hc])

add.cluster.boundaries(som_model, hc)





##3、作图，颜色代表了模块内基因平局表达值
coolBlueHotRed <- function(n, alpha = 0.7) rainbow(n, end=4/6, alpha=alpha)[n:1]

color_by <- apply(som_model$data[[1]], 1, mean)
unit_colors <- aggregate(color_by, by = list(som_model$unit.classif), FUN = mean, simplify = TRUE)
unit_dat <- data.frame(value = rep(0, 100))
unit_dat[unit_colors$Group.1,'value'] <- unit_colors$x

plot(som_model, type = 'property', property = unit_dat[[1]], palette.name = coolBlueHotRed, 
    shape = 'straight', keepMargins = TRUE, border = NA) 

##获取每个SOM中心点相关的基因
som_model_class <- data.frame(name=rownames(som_model$data[[1]]), code_class=som_model$unit.classif)
head(som_model_class)

write.table(som_model_class, 'gene_SOM.txt', row.names = FALSE, sep = '\t', quote = FALSE)

