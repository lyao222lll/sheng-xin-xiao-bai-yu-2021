##使用 igraph 包处理网络数据
library(igraph)

#输入数据示例，邻接矩阵
#“network.adj.csv”是一个微生物互作网络，数值“1”表示微生物 OTU 之间存在互作，“0”表示无互作
adjacency_unweight <- read.csv('network.adj.csv', row.names = 1, check.names = FALSE)
head(adjacency_unweight)[1:6]    #邻接矩阵类型的网络数据格式

#邻接矩阵 -> igraph 的邻接列表，获得非含权的无向网络
g <- graph_from_adjacency_matrix(as.matrix(adjacency_unweight), mode = 'undirected', weighted = NULL, diag = FALSE)
g    #igraph 的邻接列表数据格式

#本篇仅计算了部分拓扑属性，这些都是用于计算下文的“小世界系数”的主要参数
nodes_num <- length(V(g))  #节点数量（number of nodes）
nodes_num

edges_num <- length(E(g))  #边数量（number of edges）
edges_num

clustering_coefficient <- transitivity(g)  #聚类系数（clustering coefficient）
clustering_coefficient

average_path_length <- average.path.length(g, directed = FALSE)  #平均路径长度（average path length）
average_path_length

#给定与上述网络相同数量的节点和边，模拟 1000 次 ER 随机网络，并计算随机网络有关的拓扑属性
clustering_coefficient_rand <- c()
average_path_length_rand <- c()

set.seed(123)
for (i in 1:1000) {
    #生成非含权的无向的 ER 随机网络，本示例中，给定节点数量 n=100，边数量 p=920
    g_rand <- erdos.renyi.game(n = nodes_num, p = edges_num, type = 'gnm', weight = FALSE, mode = 'undirected')
    
    #记录这 1000 个随机网络的聚类系数和平均路径长度
    clustering_coefficient_rand <- c(clustering_coefficient_rand, transitivity(g_rand))
    average_path_length_rand <- c(average_path_length_rand, average.path.length(g_rand, directed = FALSE))
}

mean(clustering_coefficient_rand)  #1000 个随机网络的聚类系数的均值
sd(clustering_coefficient_rand)  #1000 个随机网络的聚类系数的标准差
mean(average_path_length_rand)  #1000 个随机网络的平均路径长度的均值
sd(average_path_length_rand)  #1000 个随机网络的平均路径长度的标准差


#根据经验网络与 1000 个随机网络，获取小世界系数
small_world_coefficient <- (clustering_coefficient/clustering_coefficient_rand) / (average_path_length/average_path_length_rand)
mean(small_world_coefficient)  #1000 个小世界系数的均值
sd(small_world_coefficient)  #1000 个小世界系数的标准差
