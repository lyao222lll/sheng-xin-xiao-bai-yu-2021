####
##使用 igraph 包处理网络数据
library(igraph)

#输入数据示例，邻接矩阵
#这是一个微生物互作网络，数值“1”表示微生物 OTU 之间存在互作，“0”表示无互作
adjacency_unweight <- read.csv('network.adj.csv', row.names = 1, check.names = FALSE)
head(adjacency_unweight)[1:6]    #邻接矩阵类型的网络数据格式

#邻接矩阵 -> igraph 的邻接列表，获得非含权的无向网络
g <- graph_from_adjacency_matrix(as.matrix(adjacency_unweight), mode = 'undirected', weighted = NULL, diag = FALSE)
g    #igraph 的邻接列表数据格式

#读取每个样品的代表 OTU
otu <- read.csv('每个样品的代表OTU.csv', row.names = 1, check.names = FALSE)

#根据样本代表节点，从网络中划分与各样本有关的“子网络”，详情 ?subgraph
#并将所有子网络存储到一个列表（list）里面
sub_graph <- list()
for (i in names(otu)) {
    sample_i <- otu[i]
    select_node <- rownames(sample_i)[which(sample_i != 0)]
    sub_graph[[i]] <- subgraph(g, select_node)
}
sub_graph

##简单画图展示全局网络或各子网络的结构，具体的可视化细节如有需要请自行摸索
library(phyloseq)

plot_network(g)  #全局网络
plot_network(sub_graph$sample1)  #以“sample1”的代表节点划分的“子网络”
plot_network(sub_graph$sample2)  #以“sample2”的代表节点划分的“子网络”
plot_network(sub_graph$sample18)  #以“sample18”的代表节点划分的“子网络”


##计算各个子网络的拓扑属性，随便选了 4 个指数为例
sample_name <- c()
nodes_num <- c()
degree <- c()
average_path_length <- c()
betweenness_centralization <- c()

for(i in 1:length(sub_graph)){
	sample_name <- c(sample_name, names(sub_graph[i]))
    nodes_num <- c(nodes_num, length(V(sub_graph[[i]])))  #节点数量
    degree <- c(degree, mean(degree(sub_graph[[i]])))  #平均度
	average_path_length <- c(average_path_length, average.path.length(sub_graph[[i]], directed = FALSE))  #平均路径长度
	betweenness_centralization <- c(betweenness_centralization, centralization.betweenness(sub_graph[[i]])$centralization)  #介数中心性
}

sub_graph_stat <- data.frame(nodes_num, degree, average_path_length, betweenness_centralization)
rownames(sub_graph_stat) <- sample_name
head(sub_graph_stat)  #与各样本有关的“子网络”的拓扑属性，本示例以节点数量、平均度、平均路径长度、介数中心性为例

#输出统计表
#write.csv(sub_graph_stat, 'subnet-拓扑属性.csv', quote = FALSE)

##“子网络”的拓扑属性与环境因子的相关性分析

#注：以下统计直接用的原始数值
#有些情况下可能需要对网络拓扑指标或者环境因子做特定的标准化处理

#读取环境因子数据
env <- read.csv('env.csv', row.names = 1)
env <- env[rownames(sub_graph_stat), ]

#本示例使用 psych 包计算“子网络”的拓扑属性与环境因子的相关性，以 spearman 相关系数为例
library(psych)

corr_matrix <- corr.test(sub_graph_stat, env, method = 'spearman', adjust = 'BH')  #本示例使用 Benjamini 校正 p 值
corr_matrix$r  #相关系数矩阵
corr_matrix$p  #p 值矩阵

#使用 corrplot 包作图展示相关系数矩阵，只展示 p<0.05 的显著相关系数
library(corrplot)
 
col1 <- colorRampPalette(c('#033A71', 'white', '#B5131C'))
corrplot(corr_matrix$r, method = 'color', col = col1(21), tl.cex = 0.8, 
    p.mat = corr_matrix$p, sig.level = 0.05, insig = 'blank')

#咦......这个示例的数据不好，没有显著的......所以图是空的

#那就展示所有的相关系数吧，不显著的也放进来了
corrplot(corr_matrix$r, method = 'color', col = col1(21), tl.cex = 0.8)

#上述展示了相关矩阵
#如果想以散点图的方式展示相关性，继续参考下文示例，尽管本示例数据没啥显著性
library(reshape2)

sub_graph_stat$samples <- rownames(sub_graph_stat)
sub_graph_stat <- melt(sub_graph_stat, id = 'samples')
env$samples <- rownames(env)
env <- melt(env, id = 'samples')
plot_data <- merge(sub_graph_stat, env, by = 'samples')  #合并数据

library(ggplot2)
library(ggpubr)

ggplot(plot_data, aes(value.x, value.y)) +
geom_point() +
geom_smooth(method = 'lm') +  #线性回归线
stat_cor(method = 'spearman', size = 2.7) +  #标识 spearman 相关系数
theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent')) +
facet_grid(variable.y~variable.x, scale = 'free') +  #分面图
labs(x = '', y = '')

