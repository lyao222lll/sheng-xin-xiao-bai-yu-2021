library(ape)  #用于读取进化树文件
library(picante)  #用于进化树剪枝
library(phyloseq)  #用于 DPCoA

#读取 OTU 丰度表
otu <- read.csv('community.csv', row.names = 1)
otu <- data.frame(t(otu))

#读取样本分组文件
samples <- read.csv('group.csv', row.names = 1)

#读取 OTU 注释表
taxon <- read.csv('taxonomy.csv', row.names = 1)

#读取 OTU 的进化树文件，并修剪系统发育树以仅包含群落数据集中存在的物种或具有非缺失性状数据的物种
tree <- read.tree('tree.nwk')
tree <- prune.sample(otu, tree)

#将上述四种类型的数据文件构建为 phyloseq 对象，详情 ?phyloseq
phy <- phyloseq(otu_table(as.matrix(otu), taxa_are_rows = FALSE), sample_data(samples), tax_table(as.matrix(taxon)), phy_tree(tree))
phy

#DPCoA，详情 ?DPCoA
#注：参数 nf 不影响 DPCoA 的计算，只是用于在已经得到的结果中保留预设的排序轴数量（例如这里为 5），去掉那些不重要的排序轴以节约存储空间
dpcoa <- DPCoA(phy, nf = 5)
dpcoa
summary(dpcoa)

##查看主要结果
names(dpcoa)

#提取查看各轴特征值
dpcoa_eig <- dpcoa$eig
names(dpcoa_eig) <- paste('CS', 1:dpcoa$rank, sep = '')
head(dpcoa_eig)
barplot(dpcoa_eig, las = 2)

#提取查看各轴贡献度
dpcoa_exp <- dpcoa_eig / sum(dpcoa_eig)
head(dpcoa_exp)
barplot(dpcoa_exp, las = 2)

#提取查看样本得分
site <- dpcoa$li
head(site)  #注：由于先前 DPCoA() 中设置 nf=5，因此只展示了前 5 个主要的轴

#提取查看物种得分
sp <- dpcoa$dls
head(sp)  #注：由于先前 DPCoA() 中设置 nf=5，因此只展示了前 5 个主要的轴

#输出样本和物种得分
#write.csv(site, 'site.csv', quote = FALSE)
#write.csv(sp, 'sp.csv', quote = FALSE)

#简单使用 phyloseq 内置函数 plot_ordination() 作图，详情 ?plot_ordination
#只展示前两个主要的排序轴
plot_ordination(phy, dpcoa, type = 'samples', axes = 1:2, color = 'group', label = 'sample_id')  #样本排序
plot_ordination(phy, dpcoa, type = 'species', axes = 1:2, color = 'phylum')  #物种排序

##评估显著性
library(ade4)

#不知为什么，用上文 phyloseq 包函数 DPCoA() 获得的 DPCoA 结果无法代入 randtest.dpcoa() 进行检验
#因此再次使用 ade4 包自带的 DPCoA 函数 dpcoa() 重新执行了 DPCoA，结果和上文 phyloseq 包获得的 DPCoA 结果是一样的
dpcoa <- dpcoa(otu, sqrt(as.dist(cophenetic(tree))), scan = FALSE, nf = 5)
plot(dpcoa)

#评估 DPCoA 显著性，详情 ?randtest.dpcoa
set.seed(123)
randtest(dpcoa, nrep = 1000, alter = 'greater')
