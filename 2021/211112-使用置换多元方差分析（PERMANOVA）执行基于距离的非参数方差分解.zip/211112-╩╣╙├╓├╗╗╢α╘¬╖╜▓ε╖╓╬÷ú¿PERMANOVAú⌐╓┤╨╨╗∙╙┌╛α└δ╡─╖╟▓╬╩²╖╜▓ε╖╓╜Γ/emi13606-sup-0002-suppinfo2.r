##############################################
############### 3-way PERMANOVA ##############
##############################################

# variation partitioning with distance matrix as response
# and X (environment) and W (space) and Z (season)
# Yeh et al., 2015

ThreeVarPartDistResponse<-function (Dist_Matrix,X,W,Z,Number_Permutations) {
  # X
  X <- as.matrix(X)
  X <- apply(X, 2, scale)
  # W
  W <- as.matrix(W)
  W <- apply(W, 2, scale)
  # add Z
  Z <- as.matrix(Z)
  Z <- apply(Z, 2, scale)

  Dist_Matrix <- as.matrix(Dist_Matrix)

  Number_Predictors_X <- ncol(X)
  Number_Predictors_W <- ncol(W)
  # add Z
  Number_Predictors_Z <- ncol(Z)

  n<-nrow(X)
  # XWZ (abcdefg)
  XWZ <- as.matrix(cbind(X,W,Z));
  result <- DistResponseReg(Dist_Matrix,XWZ);
  abcdefg <- result$Rsq_Adj;
  Fabcdefg <- result$F_value;
  # XW (abdefg)
  XW <- as.matrix(cbind(X,W));
  result <- DistResponseReg(Dist_Matrix,XW)
  abdefg <- result$Rsq_Adj
  Fabdefg <- result$F_value
  # XZ (acdefg)
  XZ <- as.matrix(cbind(X,Z));
  result <- DistResponseReg(Dist_Matrix,XZ);
  acdefg <- result$Rsq_Adj;
  Facdefg <- result$F_value;
  # WZ (bcdefg)
  WZ <- as.matrix(cbind(W,Z));
  result <- DistResponseReg(Dist_Matrix,WZ);
  bcdefg <- result$Rsq_Adj;
  Fbcdefg <- result$F_value;
  # X (abfg)
  result <- DistResponseReg(Dist_Matrix,X)
  adfg <- result$Rsq_Adj
  Fadfg <- result$F_value
  residuals_X <- result$res_matrix
  predicted_X <- result$pred_matrix
  # W (bdeg)
  result <- DistResponseReg(Dist_Matrix,W)
  bdeg <- result$Rsq_Adj
  Fbdeg <- result$F_value
  residuals_W <- result$res_matrix
  predicted_W <- result$pred_matrix
  # Z (cefg)
  result <- DistResponseReg(Dist_Matrix,Z)
  cefg <- result$Rsq_Adj
  Fcefg <- result$F_value
  residuals_Z <- result$res_matrix
  predocted_W <- result$pred_matrix

  # unique fraction
  a <- abcdefg - bcdefg
  b <- abcdefg - acdefg
  c <- abcdefg - abdefg
  d <- acdefg - cefg - a
  e <- abdefg - adfg - b
  f <- bcdefg - bdeg - c
  g <- adfg - a - d - f
  h <- 1 - abcdefg
  #######################
  Fa=(a/Number_Predictors_X)/(h/(n-Number_Predictors_X-Number_Predictors_W-Number_Predictors_Z));
  Fb=(b/Number_Predictors_W)/(h/(n-Number_Predictors_X-Number_Predictors_W-Number_Predictors_Z));
  Fc=(c/Number_Predictors_Z)/(h/(n-Number_Predictors_X-Number_Predictors_W-Number_Predictors_Z));
  #######################

  Prob_abcdefg=1/Number_Permutations;
  Prob_abdefg=1/Number_Permutations; Prob_acdefg=1/Number_Permutations; Prob_bcdefg=1/Number_Permutations;
  Prob_adfg=1/Number_Permutations; Prob_bdeg=1/Number_Permutations; Prob_cefg=1/Number_Permutations;
  Prob_ad=1/Number_Permutations; Prob_af=1/Number_Permutations; Prob_bd=1/Number_Permutations; Prob_be=1/Number_Permutations; Prob_ce=1/Number_Permutations; Prob_cf=1/Number_Permutations;
  Prob_a=1/Number_Permutations; Prob_b=1/Number_Permutations; Prob_c=1/Number_Permutations;



  # permutations test
  for (i in 1:(Number_Permutations-1)) {
    # testing fraction a; notice that we permute the residual values in W and not in X
    permuted_rows=sample(n,replace=FALSE)
    # permuting the residual matrix, which is from the distance, and hence the need to permute
    # rows and columns in the same way, hence the use of permuted_rows for columns and rows below
    # testing fraction a
    # Yperm=predicted_W+residuals_W[permuted_rows,permuted_rows] # implement permutation of residuals in the future

    # XWZ
    result <- DistResponseReg(Dist_Matrix,XWZ[permuted_rows,])
    abcdefgRnd <- result$Rsq_Adj
    FabcdefgRnd <- result$F_value

    #XW
    result <- DistResponseReg(Dist_Matrix,XW[permuted_rows,])
    abdefgRnd <- result$Rsq_Adj
    FabdefgRnd <- result$F_value

    #XZ
    result <- DistResponseReg(Dist_Matrix,XZ[permuted_rows,])
    acdefgRnd <- result$Rsq_Adj
    FacdefgRnd <- result$F_value

    #WZ
    result <- DistResponseReg(Dist_Matrix,WZ[permuted_rows,])
    bcdefgRnd <- result$Rsq_Adj
    FbcdefgRnd <- result$F_value

    #X
    result <- DistResponseReg(Dist_Matrix,X[permuted_rows,])
    adfgRnd <- result$Rsq_Adj
    FadfgRnd <- result$F_value

    #W
    result <- DistResponseReg(Dist_Matrix,W[permuted_rows,])
    bdegRnd <- result$Rsq_Adj
    FbdegRnd <- result$F_value

    #Z
    result <- DistResponseReg(Dist_Matrix,Z[permuted_rows,])
    cefgRnd <- result$Rsq_Adj
    FcefgRnd <- result$F_value

    # testing abcdefg
    if (FabcdefgRnd >= Fabcdefg) {Prob_abcdefg<-Prob_abcdefg+1/Number_Permutations}

    # testing abdefg
    if (FabdefgRnd >= Fabdefg) {Prob_abdefg<-Prob_abdefg+1/Number_Permutations}
    # testing acdefg
    if (FacdefgRnd >= Facdefg) {Prob_acdefg<-Prob_acdefg+1/Number_Permutations}
    # testing bcdefg
    if (FbcdefgRnd >= Fbcdefg) {Prob_bcdefg<-Prob_bcdefg+1/Number_Permutations}

    # testing adfg
    if (FadfgRnd >= Fadfg) {Prob_adfg<-Prob_adfg+1/Number_Permutations}
    # testing bdeg
    if (FbdegRnd >= Fbdeg) {Prob_bdeg<-Prob_bdeg+1/Number_Permutations}
    # testing cefg
    if (FcefgRnd >= Fcefg) {Prob_cefg<-Prob_cefg+1/Number_Permutations}

    aRnd = abcdefgRnd - bcdefgRnd
    bRnd = abcdefgRnd - acdefgRnd
    cRnd = abcdefgRnd - abdefgRnd
    hRnd = 1-abcdefgRnd

    FaRnd=(aRnd/Number_Predictors_X)/(hRnd/(n-Number_Predictors_X-Number_Predictors_W-Number_Predictors_Z));
    if (FaRnd >= Fa) {Prob_a<-Prob_a+1/Number_Permutations}
    FbRnd=(bRnd/Number_Predictors_W)/(hRnd/(n-Number_Predictors_X-Number_Predictors_W-Number_Predictors_Z));
    if (FbRnd >= Fb) {Prob_b<-Prob_b+1/Number_Permutations}
    FcRnd=(cRnd/Number_Predictors_Z)/(hRnd/(n-Number_Predictors_X-Number_Predictors_W-Number_Predictors_Z));
    if (FcRnd >= Fc) {Prob_c<-Prob_c+1/Number_Permutations}
  }

  result <- mat.or.vec(15,2)

  result[1,1] <- abcdefg
  result[2,1] <- abdefg
  result[3,1] <- acdefg
  result[4,1] <- bcdefg
  result[5,1] <- adfg
  result[6,1] <- bdeg
  result[7,1] <- cefg
  result[8,1] <- a
  result[9,1] <- b
  result[10,1] <- c
  result[11,1] <- d
  result[12,1] <- e
  result[13,1] <- f
  result[14,1] <- g
  result[15,1] <- h

  result[1,2] <- Prob_abcdefg
  result[2,2] <- Prob_abdefg
  result[3,2] <- Prob_acdefg
  result[4,2] <- Prob_bcdefg
  result[5,2] <- Prob_adfg
  result[6,2] <- Prob_bdeg
  result[7,2] <- Prob_cefg
  result[8,2] <- Prob_a
  result[9,2] <- Prob_b
  result[10,2] <- Prob_c
  result[11,2] <- NA
  result[12,2] <- NA
  result[13,2] <- NA
  result[14,2] <- NA
  result[15,2] <- NA

  colnames(result) <- c("Estimate","p-value")
  rownames(result) <- c("abcdefg_XWZ","abdefg_XW","acdefg_XZ","bcdefg_WZ","adfg_X","bdeg_W","cefg_Z","a","b","c","d","e","f","g","h")
  return(result)
}

# Regression approach with distance as response and raw predictors
DistResponseReg <-function (DistMatrix,X) {
  DistMatrix <- as.matrix(DistMatrix)
  X <- as.matrix(X)
  n <- nrow(DistMatrix)
  p <- ncol(X)
  row.wt = rep(1, nrow(DistMatrix))
  col.wt = rep(1, ncol(DistMatrix))
  st <- sum(col.wt)
  sr <- sum(row.wt)
  row.wt <- row.wt/sr
  col.wt <- col.wt/st
  DistMatrix <- -0.5*(DistMatrix*DistMatrix)
  row.mean <- apply(row.wt * DistMatrix, 2, sum)
  col.mean <- apply(col.wt *t(DistMatrix), 2, sum)
  col.mean <- col.mean - sum(row.mean * col.wt)
  DistMatrix <- sweep(DistMatrix, 2, row.mean)
  G <- t(sweep(t(DistMatrix), 2, col.mean))
  H<-X%*%solve(t(X)%*%X)%*%t(X)
  I<-diag(n)
  predicted <- H%*%G%*%H
  residuals <- (I-H)%*%G%*%(I-H)
  MS_regression<-sum(diag(predicted))/p
  MS_residual<-sum(diag(residuals))/(n-p)
  F<-MS_regression/MS_residual
  MS_Total=sum(diag(G))/n;
  RsqAdj=1-MS_residual/MS_Total;
  
  result <- list(Rsq_Adj=RsqAdj,F_value=F,res_matrix=residuals,pred_matrix=predicted)
  return(result)
  
}
