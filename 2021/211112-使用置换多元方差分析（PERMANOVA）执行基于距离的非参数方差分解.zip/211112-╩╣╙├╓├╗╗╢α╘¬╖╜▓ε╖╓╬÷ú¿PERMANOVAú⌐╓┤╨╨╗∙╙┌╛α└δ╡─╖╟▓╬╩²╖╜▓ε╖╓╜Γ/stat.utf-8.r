#加载 Wu等（2017）提供的基于 3-way PERMANOVA 的方差分解的运行函数 ThreeVarPartDistResponse() 和 DistResponseReg()
#下载自：https://sfamjournals.onlinelibrary.wiley.com/action/downloadSupplement?doi=10.1111%2F1462-2920.13606&file=emi13606-sup-0002-suppinfo2.R
source('emi13606-sup-0002-suppinfo2.r')

#读取微生物群落相异矩阵和环境数据
comm_dis <- read.delim('beta_distance.txt', sep = '\t', row.names = 1)
env <- read.delim('env_table.txt', sep = '\t', row.names = 1)

#例如，接下来期望分析给定的环境变量中，C、N、P 对微生物群落变异的解释度
#首先划分环境分组
C <- env[c('TC', 'DOC', 'SOM')] 
N <- env[c('TN', 'NO3', 'NH4')] 
P <- env[c('AP')]

#运行基于 3-way PERMANOVA 的方差分解，并通过 999 次置换获取显著性 P 值的估计
set.seed(123)
result <- ThreeVarPartDistResponse(Dist_Matrix = comm_dis, X = C, W = N, Z = P, Number_Permutations = 999)
result

#输出
#write.csv(result, 'result.csv')

#Estimate 是各个组分对应的方差解释率，即校正后的 R2（注意不是原始 R2）
#P 代表了显著性