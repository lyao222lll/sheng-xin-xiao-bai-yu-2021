#读取示例数据
dat <- read.delim('ko.txt', sep = '\t', row.names = 1, stringsAsFactors = FALSE, check.names = FALSE)

#首先给 ko id 排个序，默认按照原表格中的排列顺序
dat$ko.id <- factor(rownames(dat), levels = rownames(dat))

####创建一个 pdf 画板
pdf('circlize_plot.pdf', width = 13, height = 6)
circle_size = unit(1, 'snpc')

#加载 circlize 包
library(circlize)

##整体布局
circos.par(gap.degree = 2, start.degree = 90)

##第一圈，绘制 ko
plot_data <- dat[c('ko.id', 'gene_num.min', 'gene_num.max')]  #选择作图数据集，定义了 ko 区块的基因总数量范围
ko_color <- c(rep('#F7CC13', 15), rep('#954572', 2), rep('#0796E0', 3))  #定义分组颜色

circos.genomicInitialize(plot_data, plotType = NULL, major.by = 1)  #一个总布局
circos.track(
    ylim = c(0, 1), track.height = 0.05, bg.border = NA, bg.col = ko_color,  #圈图的高度、颜色等设置
    panel.fun = function(x, y) {
        ylim = get.cell.meta.data('ycenter')  #ylim、xlim 用于指定 ko id 文字标签添加的合适坐标
        xlim = get.cell.meta.data('xcenter')
        sector.name = get.cell.meta.data('sector.index')  #sector.name 用于提取 ko id 名称
        circos.axis(h = 'top', labels.cex = 0.4, major.tick.percentage = 0.4, labels.niceFacing = FALSE)  #绘制外周的刻度线
        circos.text(xlim, ylim, sector.name, cex = 0.4, niceFacing = FALSE)  #将 ko id 文字标签添加在图中指定位置处
    } )

##第二圈，绘制富集的基因和富集 p 值
plot_data <- dat[c('ko.id', 'gene_num.min', 'gene_num.rich', '-log10.p')]  #选择作图数据集，包括富集基因数量以及 p 值等信息
label_data <- dat['gene_num.rich']  #标签数据集，仅便于作图时添加相应的文字标识用
p_max <- round(max(dat$'-log10.p')) + 1  #定义一个 p 值的极值，以方便后续作图
colorsChoice <- colorRampPalette(c('#FF906F', '#861D30'))  #这两句用于定义 p 值的渐变颜色
color_assign <- colorRamp2(breaks = 0:p_max, col = colorsChoice(p_max + 1))

circos.genomicTrackPlotRegion(
    plot_data, track.height = 0.08, bg.border = NA, stack = TRUE,  #圈图的高度、颜色等设置
    panel.fun = function(region, value, ...) {
        circos.genomicRect(region, value, col = color_assign(value[[1]]), border = NA, ...)  #区块的长度反映了富集基因的数量，颜色与 p 值有关
        ylim = get.cell.meta.data('ycenter')  #同上文，ylim、xlim、sector.name 等用于指定文字标签（富集基因数量）添加的合适坐标
        xlim = label_data[get.cell.meta.data('sector.index'),1] / 2
        sector.name = label_data[get.cell.meta.data('sector.index'),1]
        circos.text(xlim, ylim, sector.name, cex = 0.4, niceFacing = FALSE)  #将文字标签添（富集基因数量）加在图中指定位置处
    } )

##第三圈，绘制上下调基因
#首先基于表格中上下调基因的数量，计算它们的占比
dat$all.regulated <- dat$up.regulated + dat$down.regulated
dat$up.proportion <- dat$up.regulated / dat$all.regulated
dat$down.proportion <- dat$down.regulated / dat$all.regulated

#随后，根据上下调基因的相对比例，分别计算它们在作图时的“区块坐标”和“长度”
dat$up <- dat$up.proportion * dat$gene_num.max
plot_data_up <- dat[c('ko.id', 'gene_num.min', 'up')]
names(plot_data_up) <- c('ko.id', 'start', 'end')
plot_data_up$type <- 1  #分配 1 指代上调基因

dat$down <- dat$down.proportion * dat$gene_num.max + dat$up
plot_data_down <- dat[c('ko.id', 'up', 'down')]
names(plot_data_down) <- c('ko.id', 'start', 'end')
plot_data_down$type <- 2  #分配 2 指代下调基因

#选择作图数据集（作图用）、标签数据集（添加相应的文字标识用），并分别为上下调基因赋值不同颜色
plot_data <- rbind(plot_data_up, plot_data_down)
label_data <- dat[c('up', 'down', 'up.regulated', 'down.regulated')]
color_assign <- colorRamp2(breaks = c(1, 2), col = c('#671166', '#7F8CCB'))

#继续绘制圈图
circos.genomicTrackPlotRegion(
    plot_data, track.height = 0.08, bg.border = NA, stack = TRUE,  #圈图的高度、颜色等设置
    panel.fun = function(region, value, ...) {
        circos.genomicRect(region, value, col = color_assign(value[[1]]), border = NA, ...)  #这里紫色代表上调基因，蓝色代表下调基因，区块的长度反映了上下调基因的相对占比
        ylim = get.cell.meta.data('cell.bottom.radius') - 0.5  #同上文，ylim、xlim、sector.name 等用于指定文字标签（上调基因数量）添加的合适坐标
        xlim = label_data[get.cell.meta.data('sector.index'),1] / 2
        sector.name = label_data[get.cell.meta.data('sector.index'),3]
        circos.text(xlim, ylim, sector.name, cex = 0.4, niceFacing = FALSE)  #将文字标签（上调基因数量）添加在图中指定位置处
        xlim = (label_data[get.cell.meta.data('sector.index'),2]+label_data[get.cell.meta.data('sector.index'),1]) / 2
        sector.name = label_data[get.cell.meta.data('sector.index'),4]
        circos.text(xlim, ylim, sector.name, cex = 0.4, niceFacing = FALSE)  #类似的操作，将下调基因数量的标签也添加在图中
    } )

##第四圈，绘制富集得分
plot_data <- dat[c('ko.id', 'gene_num.min', 'gene_num.max', 'rich.factor')]  #选择作图数据集，标准化后的富集得分
label_data <- dat['category']  #将通路的分类信息提取出，和下一句一起，便于作图时按分组分配颜色
color_assign <- c('Metabolism' = '#F7CC13', 'Environment Information Processing ' = '#954572', 'Organismal Systems' = '#0796E0')

circos.genomicTrack(
    plot_data, ylim = c(0, 1), track.height = 0.3, bg.col = 'gray95', bg.border = NA,  #圈图的高度、颜色等设置
    panel.fun = function(region, value, ...) {
        sector.name = get.cell.meta.data('sector.index')  #sector.name 用于提取 ko id 名称，并添加在下一句中匹配 ko 对应的高级分类，以分配颜色
        circos.genomicRect(region, value, col = color_assign[label_data[sector.name,1]], border = NA, ytop.column = 1, ybottom = 0, ...)  #绘制矩形区块，高度代表富集得分，颜色代表 ko 的分类
        circos.lines(c(0, max(region)), c(0.5, 0.5), col = 'gray', lwd = 0.3)  #可选在富集得分等于 0.5 的位置处添加一个灰线
    } )

##绘图完毕后，不要忘了清除痕迹，以免影响下一次作图
circos.clear()

##使用 ComplexHeatmap 包额外添加图例
library(ComplexHeatmap)

category_legend <- Legend(
    labels = c('Metabolism', 'Environment Information Processing', 'Organismal Systems'),
    type = 'points', pch = NA, background = c('#F7CC13', '#954572', '#0796E0'), 
    labels_gp = gpar(fontsize = 8), grid_height = unit(0.5, 'cm'), grid_width = unit(0.5, 'cm'))

updown_legend <- Legend(
    labels = c('Up-regulated', 'Down-regulated'), 
    type = 'points', pch = NA, background = c('#671166', '#7F8CCB'), 
    labels_gp = gpar(fontsize = 8), grid_height = unit(0.5, 'cm'), grid_width = unit(0.5, 'cm'))

pvalue_legend <- Legend(
    col_fun = colorRamp2(round(seq(0, p_max, length.out = 6), 0), 
    colorRampPalette(c('#FF906F', '#861D30'))(6)),
    legend_height = unit(3, 'cm'), labels_gp = gpar(fontsize = 8), 
    title_gp = gpar(fontsize = 9), title_position = 'topleft', title = '-Log10(Pvalue)')

lgd_list_vertical <- packLegend(category_legend, updown_legend, pvalue_legend)
pushViewport(viewport(x = 0.85, y = 0.5))
grid.draw(lgd_list_vertical)
upViewport()

##关闭 pdf 画板
dev.off()
