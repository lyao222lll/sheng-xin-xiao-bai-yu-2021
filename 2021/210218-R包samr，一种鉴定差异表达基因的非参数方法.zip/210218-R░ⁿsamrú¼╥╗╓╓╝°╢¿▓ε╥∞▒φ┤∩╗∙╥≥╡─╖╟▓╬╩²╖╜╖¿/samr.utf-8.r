#读取基因表达矩阵
gene <- read.delim('gene.txt', row.names = 1)
gene <- as.matrix(gene)

#读取样本分组信息
group <- read.delim('group.txt', row.names = 1, stringsAsFactors = FALSE)
group <- group[colnames(gene), ]

##使用 samr 包 SAMseq() 对 RNA-Seq 数据执行差异表达基因分析
library(samr)

#以下首先以非配对样本分析为例简单展示主要过程，详情 ?SAMseq
#x 为表达矩阵，y 为分组信息，通过 resp.type='Two class unpaired' 指定了非配对形式的肿瘤和非肿瘤组织的比较
#根据帮助文档的提示，当 resp.type='Two class unpaired' 时，y 参数需提前将两个比较的分组定义为 1 和 2（将分析 2 相对于 1 的上下调情况）
#这种非参数方法中，基于随机置换和重抽样的原理检验统计值，nperms 指定置换次数以估计 p 值，nresamp 用于构造检验统计量的重抽样数，random.seed 固定随机数种子
#本示例为了快速运行，仅设定了随机重排次数 100，实际上这个数值偏小，实际情况中适当增加随机重排次数以获取高可信的值
#预指定 fdr.output=0.05，也就是在输出结果中只保留输出 FDR<0.05 的差异基因
gene_sam.unpair <- SAMseq(x = gene, y = group$tissue.num, geneid = rownames(gene), genenames = rownames(gene), 
    resp.type = 'Two class unpaired', nperms = 100, nresamp = 20, random.seed = 1, fdr.output = 0.05)

#当考虑配对样本分析时，指定 resp.type='Two class paired' 执行配对的肿瘤和癌旁组织分析
#根据帮助文档，当 resp.type='Two class paired' 时，y 参数需提前定义分组为 -1,1, -2,2 ... -k,k 的形式以指定配对样本（将分析正值组相对于负值组的上下调情况）
#其它参数与上文相似，更多详情 ?SAMseq
gene_sam.pair <- SAMseq(x = gene, y = group$pair_tissues.num, geneid = rownames(gene), genenames = rownames(gene), 
    resp.type = 'Two class paired', nperms = 100, nresamp = 20, random.seed = 1, fdr.output = 0.05)

##结果筛选，由于原数据中肿瘤和癌旁组织是配对的，因此以配对样本分析的结果为例继续执行
summary(gene_sam.pair)

#其中，gene_sam.pair$siggenes.table 为差异基因统计列表，再其中 genes.up 为上调基因列表，genes.lo 为下调基因列表，ngenes.up 为上调基因数量统计，ngenes.lo 为下调基因数量统计
#关于输出结果的更多详情 ?SAMseq

#上下调基因数量的统计
gene_sam.pair$siggenes.table$ngenes.up
gene_sam.pair$siggenes.table$ngenes.lo

#提取合并基因统计列表
gene_up <- data.frame(gene_sam.pair$siggenes.table$genes.up, stringsAsFactors = FALSE, check.names = FALSE)
gene_down <- data.frame(gene_sam.pair$siggenes.table$genes.lo, stringsAsFactors = FALSE, check.names = FALSE)
gene_sam.pair_stat <- rbind(gene_up, gene_down)
head(gene_sam.pair_stat)

#将差异基因统计信息输出到本地
write.table(gene_sam.pair_stat, 'gene_sam.pair_stat.txt', row.names = FALSE, sep = '\t', quote = FALSE)

