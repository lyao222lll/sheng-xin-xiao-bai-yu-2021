#读入作图数据
dat <- read.delim('abundance.txt', stringsAsFactors = FALSE)

#使用 ggplot2 绘制相对丰度的柱形图
#此处仅为演示，未进行详细的作图参数设置
library(ggplot2)

p <- ggplot(dat, aes(taxonomy, value.mean, fill = group)) +
geom_col(position = position_dodge(width=0.8)) +
geom_errorbar(aes(ymin = value.mean - value.sd, ymax = value.mean + value.sd), width = 0.5, position=position_dodge(.8)) +
labs(x = NULL, y = NULL) +
theme(axis.text.x = element_text(angle = 45, hjust = 1), legend.title = element_blank())

p

########
#使用 coord_cartesian() 分割作图结果
#分别分割 y = c(0, 4)、c(4, 20)、c(60, 90) 区间
split1 <- p + coord_cartesian(ylim = c(0, 4)) + 
	theme(legend.position='none')
split2 <- p + coord_cartesian(ylim = c(4, 20)) + 
	theme(axis.text.x = element_blank(), axis.ticks.x = element_blank(), legend.position = 'none')
split3 <- p + coord_cartesian(ylim = c(60, 90)) + 
	theme(axis.text.x = element_blank(), axis.ticks.x = element_blank(), legend.position = c(0.95, 0.7))

split1
split2
split3

#也可使用 grid 包，组合上述分割结果，获得截断坐标轴的形式
library(grid)

#注：通过在 viewport() 中指定坐标放置图片，实现图片对齐效果
#x 和 y 分别用于指定所放置子图在画板中的坐标，坐标取值范围为 0~1，并使用 just 给定坐标起始位置
#width 和 height 用于指定所放置子图在画板中的高度和宽度
#这部分的数值可能比较难以调整，需要多加尝试
grid.newpage()
plot_site1 <- viewport(x = 0, y = 0, width = 1, height = 0.5, just = c('left', 'bottom'))
plot_site2 <- viewport(x = 0, y = 0.5, width = 1, height = 0.25, just = c('left', 'bottom'))
plot_site3 <- viewport(x = 0, y = 0.75, width = 1, height = 0.25, just = c('left', 'bottom'))
print(split1, vp = plot_site1)
print(split2, vp = plot_site2)
print(split3, vp = plot_site3)

########
#使用 ggbreak 截断坐标轴
#对于 x 轴使用 scale_x_break()，对于 y 轴使用 scale_y_break()
#参数中，breaks 用于截断坐标轴，scales 用于缩放截图，ticklabels 用于重新指定显示的刻度轴标签
library(ggbreak)

#截成两段
p + scale_y_break(breaks = c(15, 65), scales = 0.5, ticklabels = c(70, 80))

#截成三段
p + scale_y_break(breaks = c(15, 50)) + scale_y_break(breaks = c(65, 70))

#此外，ggbreak 对分面图也有效
p +
facet_wrap(~group, ncol = 3) +
scale_y_break(breaks = c(15, 65), scales = 0.5, ticklabels = c(70, 80)) +
theme(legend.position = 'none')

########
#使用 gg.gap 截断坐标轴
#在 gg.gap() 中指定 ggplot2 的作图对象，并添加参数截断坐标轴
#参数中，segments 用于截断坐标轴，rel_heights 缩放截图，tick_width 用于重新指定显示的刻度轴标签，ylim 指定刻度轴范围
library(gg.gap)

#截成两段
gg.gap(plot = p, segments = c(15, 65), rel_heights = c(0.7, 0, 0.2), tick_width = c(5, 10), ylim = c(0, 90))

#截成三段
gg.gap(plot = p, segments = list(c(15, 50), c(65, 70)), rel_heights = c(0.4, 0, 0.1, 0, 0.1), tick_width = c(5, 10, 10), ylim = c(0, 90))
