#加载 R 包，其中 ggplot2 用于作图，gtable 用于提取图像属性，grid 用于合并图像
library(ggplot2)
library(gtable)
library(grid)

# 定义函数，用于组合 ggplot2 绘图结果构建双坐标轴，参考自：
# https://stackoverflow.com/questions/36754891/ggplot2-adding-secondary-y-axis-on-top-of-a-plot

y2_plot <- function(p1, p2) {
    p1 <- ggplotGrob(p1)
    p2 <- ggplotGrob(p2)
    
    # Get the location of the plot panel in p1.
    # These are used later when transformed elements of p2 are put back into p1
    pp <- c(subset(p1$layout, name == 'panel', se = t:r))
    
    # Overlap panel for second plot on that of the first plot
    p1 <- gtable_add_grob(p1, p2$grobs[[which(p2$layout$name == 'panel')]], pp$t, pp$l, pp$b, pp$l)
    
    # Then proceed as before:
    
    # ggplot contains many labels that are themselves complex grob; 
    # usually a text grob surrounded by margins.
    # When moving the grobs from, say, the left to the right of a plot,
    # Make sure the margins and the justifications are swapped around.
    # The function below does the swapping.
    # Taken from the cowplot package:
    # https://github.com/wilkelab/cowplot/blob/master/R/switch_axis.R 
    
    hinvert_title_grob <- function(grob){
    
        # Swap the widths
        widths <- grob$widths
        grob$widths[1] <- widths[3]
        grob$widths[3] <- widths[1]
        grob$vp[[1]]$layout$widths[1] <- widths[3]
        grob$vp[[1]]$layout$widths[3] <- widths[1]
        
        # Fix the justification
        grob$children[[1]]$hjust <- 1 - grob$children[[1]]$hjust 
        grob$children[[1]]$vjust <- 1 - grob$children[[1]]$vjust 
        grob$children[[1]]$x <- unit(1, 'npc') - grob$children[[1]]$x
        grob
    }
    
    # Get the y axis title from p2
    index <- which(p2$layout$name == 'ylab-l') # Which grob contains the y axis title?
    ylab <- p2$grobs[[index]]                # Extract that grob
    ylab <- hinvert_title_grob(ylab)         # Swap margins and fix justifications

    # Put the transformed label on the right side of p1
    p1 <- gtable_add_cols(p1, p2$widths[p2$layout[index, ]$l], pp$r)
    p1 <- gtable_add_grob(p1, ylab, pp$t, pp$r + 1, pp$b, pp$r + 1, clip = 'off', name = 'ylab-r')
    
    # Get the y axis from p2 (axis line, tick marks, and tick mark labels)
    index <- which(p2$layout$name == 'axis-l')  # Which grob
    yaxis <- p2$grobs[[index]]                  # Extract the grob
    
    # yaxis is a complex of grobs containing the axis line, the tick marks, and the tick mark labels.
    # The relevant grobs are contained in axis$children:
    #   axis$children[[1]] contains the axis line;
    #   axis$children[[2]] contains the tick marks and tick mark labels.
    
    # First, move the axis line to the left
    yaxis$children[[1]]$x <- unit.c(unit(0, 'npc'), unit(0, 'npc'))
    
    # Second, swap tick marks and tick mark labels
    ticks <- yaxis$children[[2]]
    ticks$widths <- rev(ticks$widths)
    ticks$grobs <- rev(ticks$grobs)
    
    # Third, move the tick marks
    ticks$grobs[[1]]$x <- ticks$grobs[[1]]$x - unit(1, 'npc') + unit(3, 'pt')
    
    # Fourth, swap margins and fix justifications for the tick mark labels
    ticks$grobs[[2]] <- hinvert_title_grob(ticks$grobs[[2]])
    
    # Fifth, put ticks back into yaxis
    yaxis$children[[2]] <- ticks
    
    # Put the transformed yaxis on the right side of p1
    p1 <- gtable_add_cols(p1, p2$widths[p2$layout[index, ]$l], pp$r)
    p1 <- gtable_add_grob(p1, yaxis, pp$t, pp$r + 1, pp$b, pp$r + 1, clip = 'off', name = 'axis-r')
    grid.newpage()
    grid.draw(p1)
}

#-------------------------------- ggplot2 绘图，并整合结果 --------------------------------

##示例 1
#使用的 R 自带的 mtcars 数据集，绘制“mpg-disp”与“mpg-drat”折线图，并尝试组合展示
#“mpg-disp”的折线图
p1 <- ggplot(mtcars, aes(mpg, disp)) +
geom_line(color = 'blue') +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = NA, color = 'black'), 
    axis.text.y = element_text(color = 'blue'), axis.ticks.y = element_line(color = 'blue'), 
    axis.title.y = element_text(color = 'blue')) +
labs(y = 'disp')

p1

#“mpg-drat”的折线图
p2 <- ggplot(mtcars, aes(mpg, drat)) +
geom_line(color = 'red') +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = NA, color = 'black'),
    axis.text.y = element_text(color = 'red'), axis.ticks.y = element_line(color = 'red'), 
    axis.title.y = element_text(color = 'red')) +
labs(y = 'drat')

p2

#两张图共用同一 x 轴，尝试组合到一起，组合后默认第一张图的 y 轴在左侧，第二张图的 y 轴在右侧
y2_plot(p1, p2)

#输出图片
ggsave('p12.pdf', y2_plot(p1, p2)[2], width = 5, height = 4)
ggsave('p12.png', y2_plot(p1, p2), width = 5, height = 4)


##示例 2
#作物种植面积和产量的数据
dat2 <- read.delim('example_data2.txt', check.names = FALSE)

##散点图带时间标签
p0 <- ggplot(dat2, aes(`Area/×103 ha`,`Yield/×103 t`, color = Year, label = Year)) +
geom_point() +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = NA, color = 'black')) +
geom_text(vjust = 1.5, size = 2.5) +
labs(x = expression('Area / ×'*10^{3}*'ha'), y = expression('Yield / ×'*10^{3}*'t'))

p0

##双 y 轴的组合图样式
#种植年份和种植面积的柱形图
p1 <- ggplot(dat2, aes(Year, `Area/×103 ha`)) +
geom_col(fill = 'red', color = NA, width = 0.5) +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = NA, color = 'black'), 
    axis.text.y = element_text(color = 'red'), axis.ticks.y = element_line(color = 'red'), 
	axis.title.y = element_text(color = 'red'), axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1)) +
scale_y_continuous(expand = c(0, 0), limits = c(0, max(dat2$'Area/×103 ha')*1.2)) +
scale_x_continuous(breaks = dat2$Year, labels = dat2$Year) +
labs(x = '', y = expression('Area / ×'*10^{3}*'ha'))

p1

#种植年份和作物产量的折线图
p2 <- ggplot(dat2, aes(Year, `Yield/×103 t`)) +
geom_line(color = 'blue') +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = NA, color = 'black'), 
    axis.text.y = element_text(color = 'blue'), axis.ticks.y = element_line(color = 'blue'), 
	axis.title.y = element_text(color = 'blue'), axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1)) +
scale_y_continuous(expand = c(0, 0), limits = c(0, max(dat2$'Yield/×103 t')*1.2)) +
scale_x_continuous(breaks = dat2$Year, labels = dat2$Year) +
labs(x = '', y = expression('Yield / ×'*10^{3}*'t'))

p2

#两张图共用同一 x 轴，尝试组合到一起，组合后默认第一张图的 y 轴在左侧，第二张图的 y 轴在右侧
y2_plot(p1, p2)

#输出图片
ggsave('dat2_p12.pdf', y2_plot(p1, p2)[2], width = 7, height = 4)
ggsave('dat2_p12.png', y2_plot(p1, p2), width = 7, height = 4)

##示例 3
#细菌分类群的丰度数据
dat3 <- read.delim('example_data3.txt', check.names = FALSE, stringsAsFactors = FALSE)

#可选按丰度高低排个序
dat3 <- dat3[order(dat3$count, decreasing = TRUE), ]
dat3$taxonomy <- factor(dat3$taxonomy, levels = unique(dat3$taxonomy))

#绝对丰度的计数值柱形图
p1 <- ggplot(dat3, aes(taxonomy, count, fill = group)) +
geom_col(position = position_dodge(width = 0.9), width = 0.7) +
scale_fill_manual(values = c('#B3DE69', '#FDB462', '#80B1D3')) +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = NA, color = 'black'), 
    axis.line = element_line(colour = 'black'), axis.text.x = element_text(angle = 45, hjust = 1), 
    legend.position = c(0.9, 0.8)) +
scale_y_continuous(expand = c(0, 0), limit = c(0, max(dat3$count)*1.2)) +
labs(title = NULL, x = NULL, y = 'Count', fill = NULL)

p1

#相对丰度的比值柱形图
p2 <- ggplot(dat3, aes(taxonomy, relative_abundance*100, fill = group)) +
geom_col(position = position_dodge(width = 0.9), width = 0.7) +
scale_fill_manual(values = c('#B3DE69', '#FDB462', '#80B1D3')) +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = NA, color = 'black'), 
    axis.line = element_line(colour = 'black'), axis.text.x = element_text(angle = 45, hjust = 1), 
    legend.position = 'none') +
scale_y_continuous(expand = c(0, 0), limit = c(0, max(dat3$relative_abundance)*100*1.2)) +
labs(title = NULL, x = NULL, y = 'Relative abundance (%)')

p2

#两张图共用同一 x 轴，尝试组合到一起，组合后默认第一张图的 y 轴在左侧，第二张图的 y 轴在右侧
y2_plot(p1, p2)

#输出图片
ggsave('dat3_p12.pdf', y2_plot(p1, p2)[2], width = 7, height = 4)
ggsave('dat3_p12.png', y2_plot(p1, p2), width = 7, height = 4)

##如果您想让左侧 y 轴和右侧 y 轴的丰度数值标签对齐
#绝对丰度的计数值柱形图，此时需要在 scale_y_continuous() 中定义好想展示的刻度
p1 <- ggplot(dat3, aes(taxonomy, count, fill = group)) +
geom_col(position = position_dodge(width = 0.9), width = 0.7) +
scale_fill_manual(values = c('#B3DE69', '#FDB462', '#80B1D3')) +
theme(panel.grid.major.y = element_line(linetype = 2, color = 'gray'), 
    panel.background = element_rect(fill = NA, color = 'black'), legend.position = c(0.9, 0.8), 
    axis.line = element_line(colour = 'black'), axis.text.x = element_text(angle = 45, hjust = 1)) +
scale_y_continuous(expand = c(0, 0), limit = c(0, 6200), 
    breaks = c(0, 2000, 4000, 6000), labels = c(0, 2000, 4000, 6000)) +
labs(title = NULL, x = NULL, y = 'Count', fill = NULL)

p1

#相对丰度的比值柱形图，仍然使用用计数值作图，然后在 scale_y_continuous() 中的指定刻度处更改为比值信息
#注：scale_y_continuous() 里除的 14210，为示例数据中所有物种丰度的总数（包含数据中未展示的其它物种丰度），需要提前计算好，文中未提及，注意下即可
p2 <- ggplot(dat3, aes(taxonomy, count, fill = group)) +
geom_col(position = position_dodge(width = 0.9), width = 0.7) +
scale_fill_manual(values = c('#B3DE69', '#FDB462', '#80B1D3')) +
theme(panel.grid.major.y = element_line(linetype = 2, color = 'gray'), 
    panel.background = element_rect(fill = NA, color = 'black'), legend.position = 'none', 
    axis.line = element_line(colour = 'black'), axis.text.x = element_text(angle = 45, hjust = 1)) +
scale_y_continuous(expand = c(0, 0), limit = c(0, 6200), 
    breaks = c(0, 2000, 4000, 6000), labels = round(c(0, 2000, 4000, 6000)/14210*100, 2)) +
labs(title = NULL, x = NULL, y = 'Relative abundance (%)')

p2

#两张图共用同一 x 轴，尝试组合到一起，组合后默认第一张图的 y 轴在左侧，第二张图的 y 轴在右侧
y2_plot(p1, p2)
