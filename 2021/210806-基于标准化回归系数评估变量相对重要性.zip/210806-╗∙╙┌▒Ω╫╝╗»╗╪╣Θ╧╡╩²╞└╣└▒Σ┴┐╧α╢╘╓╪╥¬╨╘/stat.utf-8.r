#读取鱼类物种丰度和水体环境数据
dat <- read.delim('fish_data.txt', sep = '\t', row.names = 1)

#对所有变量进行标准化处理，例如所有都标准化到均值 0，标准差 1 的区间
#注：如果您采用这种通过比较标准化回归系数评估变量相对重要性的方法，变量标准化是必须的
dat <- data.frame(scale(dat))

#首先不妨使用全部环境变量拟合与鱼类物种丰度的多元线性回归，详情 ?lm
fit.lm <- lm(fish~acre+do2+depth+no3+so4+temp, data = dat)
summary(fit.lm)  #展示拟合回归的简单统计

#注：本示例为了方便操作，暂且忽略了可能存在的多重共线性问题，没有优化模型，实际情况中需认真对待

#如果有需要，提取包括回归系数、标准误、P 值等在内的统计量
stat.lm <- summary(fit.lm)$coefficients
stat.lm

#输出到本地保存
#write.csv(stat.lm, 'stat.lm.csv')

#绘制森林图展示每个自变量的标准化回归系数、标准误、P 值结果
library(ggplot2)

stat.lm <- data.frame(stat.lm, check.names = FALSE)
stat.lm$env <- rownames(stat.lm)
stat.lm$sig <- ifelse(stat.lm$'Pr(>|t|)'<0.05, '0', '1')

ggplot(stat.lm[-1, ], aes(x = env, y = Estimate)) +  #x 轴环境变量，y 轴标准化后的回归系数（最后再对 x、y 作个翻转）
geom_point(aes(shape = sig), size = 2, show.legend = FALSE) +  #将 P 显著的回归系数绘制为实心点，不显著的绘制为空心点
scale_shape_manual(values = c(15, 0)) +
geom_errorbar(aes(ymin = Estimate - `Std. Error`, ymax = Estimate + `Std. Error`), width = 0.25) +  #误差线表示回归系数的标准误
geom_hline(yintercept = 0, linetype = 2) +  #0 位置处画一个虚线
labs(x = '', y = 'Standardized Mean', title = expression(R^{2}*'.adj = 0.247, P < 0.001')) +  #顺便手动把全模型的 R2 和 P 值添加到标题里面了
theme(panel.grid = element_blank(), panel.background = element_blank(), plot.title = element_text(size = 9), 
    axis.ticks.y = element_blank(), axis.line.x = element_line(color = 'black')) +
coord_flip()  #横纵轴作个翻转

###############

#读取鱼类物种丰度和水体环境数据
dat <- read.delim('fish_data.txt', sep = '\t', row.names = 1)

#对所有自变量进行标准化处理，例如所有都标准化到均值 0，标准差 1 的区间
#注：此时由于使用泊松回归，不要对因变量标准化，因为要保证因变量是计数型变量
dat[2:ncol(dat)] <- data.frame(scale(dat[2:ncol(dat)]))  #第一列是因变量，未对其标准化；从第二列开始，所有自变量标准化

#使用全部环境变量拟合与鱼类物种丰度关系的广义线性模型
#详情 ?glm，这里通过 family 参数指定了准泊松回归（考虑到标准泊松回归可能发生偏大离差的问题，使用准泊松回归替代）
fit.quasipoisson <- glm(fish~acre+do2+depth+no3+so4+temp, data = dat, family = 'quasipoisson')
summary.glm(fit.quasipoisson)  #展示拟合回归的简单统计

#注：本示例为了方便操作，暂且忽略了可能存在的多重共线性问题，没有优化模型，实际情况中需认真对待

#如果有需要，提取包括回归系数、标准误、P 值等在内的统计量
stat.quasipoisson <- summary(fit.quasipoisson)$coefficients
stat.quasipoisson

#输出到本地保存
#write.csv(stat.quasipoisson, 'stat.quasipoisson.csv')

#绘制森林图展示每个自变量的标准化回归系数、标准误、P 值结果
library(ggplot2)

stat.quasipoisson <- data.frame(stat.quasipoisson, check.names = FALSE)
stat.quasipoisson$env <- rownames(stat.quasipoisson)
stat.quasipoisson$sig <- ifelse(stat.quasipoisson$'Pr(>|t|)'<0.05, '0', '1')

ggplot(stat.quasipoisson[-1, ], aes(x = env, y = Estimate)) +  #x 轴环境变量，y 轴标准化后的回归系数（最后再对 x、y 作个翻转）
geom_point(aes(shape = sig), size = 2, show.legend = FALSE) +  #将 P 显著的回归系数绘制为实心点，不显著的绘制为空心点
scale_shape_manual(values = c(15, 0)) +
geom_errorbar(aes(ymin = Estimate - `Std. Error`, ymax = Estimate + `Std. Error`), width = 0.25) +  #误差线表示回归系数的标准误
geom_hline(yintercept = 0, linetype = 2) +  #0 位置处画一个虚线
labs(x = '', y = 'Standardized Mean') + 
theme(panel.grid = element_blank(), panel.background = element_blank(), plot.title = element_text(size = 9), 
    axis.ticks.y = element_blank(), axis.line.x = element_line(color = 'black')) +
coord_flip()  #横纵轴作个翻转
