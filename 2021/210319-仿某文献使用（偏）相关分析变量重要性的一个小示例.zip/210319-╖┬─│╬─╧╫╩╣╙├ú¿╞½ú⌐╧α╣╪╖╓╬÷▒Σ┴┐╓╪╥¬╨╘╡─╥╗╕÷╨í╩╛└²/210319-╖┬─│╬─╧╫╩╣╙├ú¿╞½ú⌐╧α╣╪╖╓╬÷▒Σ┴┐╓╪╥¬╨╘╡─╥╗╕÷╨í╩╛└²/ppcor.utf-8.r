#读取数据
emf <- read.delim('ENV_EMF.txt', row.names = 1, sep = '\t')

##使用 Hmisc 包计算常规的相关系数
library(Hmisc)

#计算变量间的相关性，以 spearman 相关系数为例
emf_cor <- rcorr(as.matrix(emf), type = 'spearman')

#相关系数 r 值和显著性 p 值矩阵
emf_cor$r  #变量间的相关系数（r 值）矩阵
emf_cor$P  #相关系数的显著性（p 值）矩阵

##使用 ppcor 包计算偏相关系数
#也就是在控制 z 变量时，x 和 y 的偏相关系数计算
library(ppcor)

#控制 Space 的前提下，Environment 和 EMF 的 spearman 偏相关系数
pcor.test(x = emf$Environment, y = emf$EMF, z = emf$Space, method = 'spearman')
#控制 Space 的前提下，Species 和 EMF 的 spearman 偏相关系数
pcor.test(x = emf$Species, y = emf$EMF, z = emf$Space, method = 'spearman')

#控制 Environment 的前提下，Space 和 EMF 的 spearman 偏相关系数
pcor.test(x = emf$Space, y = emf$EMF, z = emf$Environment, method = 'spearman')
#控制 Environment 的前提下，Species 和 EMF 的 spearman 偏相关系数
pcor.test(x = emf$Species, y = emf$EMF, z = emf$Environment, method = 'spearman')

#控制 Species 的前提下，Space 和 EMF 的 spearman 偏相关系数
pcor.test(x = emf$Space, y = emf$EMF, z = emf$Species, method = 'spearman')
#控制 Species 的前提下，Environment 和 EMF 的 spearman 偏相关系数
pcor.test(x = emf$Environment, y = emf$EMF, z = emf$Species, method = 'spearman')

##矩阵图（模仿上文文献中的可视化样式绘制，细节上略有区别）
#将上述相关系数和偏相关系数手动整理至表格中，然后再读取到 R 中
plot_dat <- read.delim('cor_result.txt', stringsAsFactors = FALSE)

#对因子变量排个序，方便作图时按预期的顺序展示
plot_dat$partial_correlation_control <- factor(plot_dat$partial_correlation_control, levels = c('Zero-order', 'Space', 'Environment', 'Species'))
plot_dat$variable1 <- factor(plot_dat$variable1, levels = c('Species', 'Environment', 'Space'))

#使用 ggplot2 绘制热图
library(ggplot2)

ggplot(plot_dat, aes(x = partial_correlation_control, y = variable1)) +
geom_tile(aes(fill = spearman))+  #绘制热图
scale_fill_gradientn(colors = c('blue', 'grey95', 'red'), limit = c(-1, 1)) +  #自定义热图渐变填充色，例如负相关蓝色，正相关红色
geom_text(aes(label = sig), size = 2.8) +  #在热图中展示指定列的标签文字
facet_grid(~variable2) +  #分面图
theme(axis.line = element_blank(), axis.ticks = element_blank(), axis.text = element_text(color = 'black')) +  #去除了刻度轴线条，并调整了坐标轴字体的风格
labs(x = '\nPartial correlation control', y = '', fill = "(Partial)\ncorrelations\n\nSpearman's r") +  #坐标轴标题和图例标题
scale_x_discrete(expand = c(0, 0)) +  #以下两句用于坐标轴紧贴热图
scale_y_discrete(expand = c(0, 0))

