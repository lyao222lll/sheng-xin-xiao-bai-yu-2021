#ggplot2 用于作图，gtable 用于提取图像属性，grid 用于合并三个图像获得三 y 轴图。
library(ggplot2)
library(gtable)
library(grid)
 
#自定义函数，用于组合 ggplot2 绘图结果构建三个坐标轴
#改编自先前绘制双坐标轴的一个自定义函数，原双坐标轴函数可见：https://mp.weixin.qq.com/s/DnotJG4ic8fqFwikkf5QKQ
y3_plot <- function(gp1, gp2, gp3) {
    p1 <- ggplotGrob(gp1)
    p2 <- ggplotGrob(gp2)
    p3 <- ggplotGrob(gp3)
    
    # Get the location of the plot panel in p1.
    # These are used later when transformed elements of p2 are put back into p1
    pp <- c(subset(p1$layout, name == 'panel', se = t:r))
    
    # Overlap panel for second plot on that of the first plot
    p1 <- gtable_add_grob(p1, p2$grobs[[which(p2$layout$name == 'panel')]], pp$t, pp$l, pp$b, pp$l)
    p1 <- gtable_add_grob(p1, p3$grobs[[which(p3$layout$name == 'panel')]], pp$t, pp$l, pp$b*0.0001, pp$l)
    
    # Then proceed as before:
    
    # ggplot contains many labels that are themselves complex grob; 
    # usually a text grob surrounded by margins.
    # When moving the grobs from, say, the left to the right of a plot,
    # Make sure the margins and the justifications are swapped around.
    # The function below does the swapping.
    # Taken from the cowplot package:
    # https://github.com/wilkelab/cowplot/blob/master/R/switch_axis.R 
    
    hinvert_title_grob <- function(grob){
    
        # Swap the widths
        widths <- grob$widths
        grob$widths[1] <- widths[3]
        grob$widths[3] <- widths[1]
        grob$vp[[1]]$layout$widths[1] <- widths[3]
        grob$vp[[1]]$layout$widths[3] <- widths[1]
        
        # Fix the justification
        grob$children[[1]]$hjust <- 1 - grob$children[[1]]$hjust 
        grob$children[[1]]$vjust <- 1 - grob$children[[1]]$vjust 
        grob$children[[1]]$x <- unit(1, 'npc') - grob$children[[1]]$x
        grob
    }
    
    #### add p3
    # Get the y axis title from p3
    index <- which(p3$layout$name == 'ylab-l') # Which grob contains the y axis title?
    ylab <- p3$grobs[[index]]                # Extract that grob
    ylab <- hinvert_title_grob(ylab)         # Swap margins and fix justifications
 
    # Put the transformed label on the right side of p1
    p1 <- gtable_add_cols(p1, p3$widths[p3$layout[index, ]$l], pp$r)
    p1 <- gtable_add_grob(p1, ylab, pp$t, pp$r + 1, pp$b, pp$r + 1, clip = 'off', name = 'ylab-r')
    
    # Get the y axis from p3 (axis line, tick marks, and tick mark labels)
    index <- which(p3$layout$name == 'axis-l')  # Which grob
    yaxis <- p3$grobs[[index]]                  # Extract the grob
    
    # yaxis is a complex of grobs containing the axis line, the tick marks, and the tick mark labels.
    # The relevant grobs are contained in axis$children:
    #   axis$children[[1]] contains the axis line;
    #   axis$children[[2]] contains the tick marks and tick mark labels.
    
    # First, move the axis line to the left
    yaxis$children[[1]]$x <- unit.c(unit(0, 'npc'), unit(0, 'npc'))
    
    # Second, swap tick marks and tick mark labels
    ticks <- yaxis$children[[2]]
    ticks$widths <- rev(ticks$widths)
    ticks$grobs <- rev(ticks$grobs)
    
    # Third, move the tick marks
    ticks$grobs[[1]]$x <- ticks$grobs[[1]]$x - unit(1, 'npc') + unit(3, 'pt')
    
    # Fourth, swap margins and fix justifications for the tick mark labels
    ticks$grobs[[2]] <- hinvert_title_grob(ticks$grobs[[2]])
    
    # Fifth, put ticks back into yaxis
    yaxis$children[[2]] <- ticks
    
    # Put the transformed yaxis on the right side of p1
    p1 <- gtable_add_cols(p1, p3$widths[p3$layout[index, ]$l], pp$r)
    p1 <- gtable_add_grob(p1, yaxis, pp$t, pp$r + 1, pp$b, pp$r + 1, clip = 'off', name = 'axis-r')
    
    #### add p2
    # Get the y axis title from p2
    index <- which(p2$layout$name == 'ylab-l') # Which grob contains the y axis title?
    ylab <- p2$grobs[[index]]                # Extract that grob
    ylab <- hinvert_title_grob(ylab)         # Swap margins and fix justifications
 
    # Put the transformed label on the right side of p1
    p1 <- gtable_add_cols(p1, p2$widths[p2$layout[index, ]$l], pp$r)
    p1 <- gtable_add_grob(p1, ylab, pp$t, pp$r + 1, pp$b, pp$r + 1, clip = 'off', name = 'ylab-r')
    
    # Get the y axis from p2 (axis line, tick marks, and tick mark labels)
    index <- which(p2$layout$name == 'axis-l')  # Which grob
    yaxis <- p2$grobs[[index]]                  # Extract the grob
    
    # yaxis is a complex of grobs containing the axis line, the tick marks, and the tick mark labels.
    # The relevant grobs are contained in axis$children:
    #   axis$children[[1]] contains the axis line;
    #   axis$children[[2]] contains the tick marks and tick mark labels.
    
    # First, move the axis line to the left
    yaxis$children[[1]]$x <- unit.c(unit(0, 'npc'), unit(0, 'npc'))
    
    # Second, swap tick marks and tick mark labels
    ticks <- yaxis$children[[2]]
    ticks$widths <- rev(ticks$widths)
    ticks$grobs <- rev(ticks$grobs)
    
    # Third, move the tick marks
    ticks$grobs[[1]]$x <- ticks$grobs[[1]]$x - unit(1, 'npc') + unit(3, 'pt')
    
    # Fourth, swap margins and fix justifications for the tick mark labels
    ticks$grobs[[2]] <- hinvert_title_grob(ticks$grobs[[2]])
    
    # Fifth, put ticks back into yaxis
    yaxis$children[[2]] <- ticks
    
    # Put the transformed yaxis on the right side of p1
    p1 <- gtable_add_cols(p1, p2$widths[p2$layout[index, ]$l], pp$r)
    p1 <- gtable_add_grob(p1, yaxis, pp$t, pp$r + 1, pp$b, pp$r + 1, clip = 'off', name = 'axis-r')
    grid.newpage()
    grid.draw(p1)
}

#读取数据
dat <- read.delim('某省某作物的种植面积和产量数据.txt', check.names = FALSE, stringsAsFactors = FALSE)

#绘制面积曲线图（作为图的主题部分，绘制一个完全图）
p_area <- ggplot(data = dat, aes(x = year, y = `area (1000ha)`)) +
geom_point(color = 'red') + 
geom_line(color = 'red') + 
theme(panel.grid = element_blank(), panel.background = element_rect(fill = NA, color = 'black'), 
    axis.text.y = element_text(color = 'red'), axis.ticks.y = element_line(color = 'red'), 
    axis.title.y = element_text(color = 'red'), axis.line.y = element_line(color = 'red'), 
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1)) +
scale_y_continuous(expand = c(0, 0), limits = c(0, max(dat$'area (1000ha)')*1.2)) +
scale_x_continuous(breaks = dat$year, labels = dat$year) +
labs(x = '', y = expression('Area ('*10^{3}*'ha)'))

p_area

#绘制产量曲线图（作为副图参与组合，不要绘制背景框）
p_yield <- ggplot(data = dat, aes(x = year, y = `yield (1000t)`)) +
geom_point(color = 'blue') + 
geom_line(color = 'blue') + 
theme(panel.grid = element_blank(), panel.background = element_rect(fill = NA, color = NA), 
    axis.text.y = element_text(color = 'blue'), axis.ticks.y = element_line(color = 'blue'), 
    axis.title.y = element_text(color = 'blue'), axis.line.y = element_line(color = 'blue'), 
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1)) +
scale_y_continuous(expand = c(0, 0), limits = c(0, max(dat$'yield (1000t)')*1.2)) +
scale_x_continuous(breaks = dat$year, labels = dat$year) +
labs(x = '', y = expression('Yield ('*10^{3}*'t)'))

p_yield

#绘制单位面积产量曲线图（作为副图参与组合，不要绘制背景框）
p_area_yield <- ggplot(data = dat, aes(x = year, y = `yield/area (t/ha)`)) +
geom_point(color = 'green3') + 
geom_line(color = 'green3') + 
theme(panel.grid = element_blank(), panel.background = element_rect(fill = NA, color = NA), 
    axis.text.y = element_text(color = 'green3'), axis.ticks.y = element_line(color = 'green3'), 
    axis.title.y = element_text(color = 'green3'), axis.line.y = element_line(color = 'green3'), 
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1)) +
scale_y_continuous(expand = c(0, 0), limits = c(0, max(dat$'yield/area (t/ha)')*1.2)) +
scale_x_continuous(breaks = dat$year, labels = dat$year) +
labs(x = '', y = 'Area/Yield (t/ha)')

p_area_yield

#调用上文自定义函数 y3_plot() 组合上述三个图
#左侧轴为总面积，右侧轴为总产量，最右侧边外轴为单位面积产量
y3_plot(gp1 = p_area, gp2 = p_yield, gp3 = p_area_yield)

