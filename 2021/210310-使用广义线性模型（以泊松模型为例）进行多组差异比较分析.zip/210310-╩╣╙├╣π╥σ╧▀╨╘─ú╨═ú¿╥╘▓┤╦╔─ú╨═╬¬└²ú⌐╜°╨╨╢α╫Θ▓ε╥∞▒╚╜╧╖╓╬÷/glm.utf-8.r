#读取数据
worm <- read.csv('Lab_exp.csv', stringsAsFactors = FALSE)

#评估计数型响应变量（D. pseudospathaceum 丰度）的分布特征
library(ggplot2)

ggplot(worm, aes(x = Diplo_intensity, stat(density))) +
geom_histogram(aes(fill = Treatment, color = Treatment), bins = 30, alpha = 0.2)

ggplot(worm, aes(x = Diplo_intensity, stat(density))) +
geom_line(aes(color = Treatment), stat = 'density', size = 1.5)

#已知 D. pseudospathaceum 的丰度是正整数，且分布曲线呈现左偏的单峰
#可以考虑执行泊松回归或者负二项回归

##执行泊松回归
#由于在这里自变量是一组分类值而非连续值，因此可用作多组的差异比较分析
#首先预定义自变量的分组因子水平，如果存在处理浓度或时间等类型“梯度”数据，可据此对有序因子实现“梯度”的排序
#例如这里按不同强度的 S. solidus 侵染试验条件定义分组因子水平
worm$Treatment <- factor(worm$Treatment, levels = c('Control', 'Uninfected', 'Infected LG', 'Infected HG'))

#评估响应变量是否存在偏大离差问题
#零假设不存在偏大离差，若检验 p 值显著，则拒绝零假设，偏大离差存在
library(qcc)
qcc.overdispersion.test(worm$Diplo_intensity, type = 'poisson')

#已知上述结果 p<0.05，意味着响应变量（D. pseudospathaceum 丰度）存在偏大离差问题
#此时可以执行考虑了偏大离差问题的泊松模型，也就是准泊松回归（也常称为偏大离差的泊松回归）

#拟合广义线性模型，详情 ?glm
#这里通过 family='quasipoisson' 参数指定了准泊松回归（若不存在偏大离差问题，执行常规的泊松回归即可，即 family='poisson'）
fit_quasipoisson <- glm(Diplo_intensity~Treatment, data = worm, family = 'quasipoisson')
summary.glm(fit_quasipoisson)  #查看广义线性模型（准泊松回归）概要

##执行了广义线性模型（准泊松回归）的多组比较后，可继续通过事后多重比较探寻两两分组间的差异
#multcomp 包提供了直观的结果比较，例如使用 Tukey HSD 检验继续比较两两差异
library(multcomp)

tuk_quasipoisson <- glht(fit_quasipoisson, alternative = 'two.sided', linfct = mcp(Treatment = 'Tukey'))
summary(tuk_quasipoisson)  #查看 Tukey HSD 概要

tuk_quasipoisson.cld <- cld(tuk_quasipoisson, level = 0.05, decreasing = TRUE)
tuk_quasipoisson.cld  #按差异高低自动标识了 a、b、c 水平
plot(tuk_quasipoisson.cld, col = c('#7CBAD8', '#E1EBF4', '#D3E599', '#F9D2B8'))

##当广义线性模型的自变量为类别或因子型时，R 函数 glm() 是如何处理的？

#查看自变量预定义的因子水平和顺序
levels(worm$Treatment)

#通过 contrasts() 查看名义变量的编码过程
contrasts(worm$Treatment)

#查看上文广义线性模型（准泊松回归）的结果概要
summary.glm(fit_quasipoisson)
