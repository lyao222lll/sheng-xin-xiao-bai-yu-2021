#高版本的 R 好像不支持这个 R 包？
#我用 R3.3 等版本能成功安装上，但是 R3.6、R4.0 等版本却不行 
#install.packages('packfor', repos = 'http://R-Forge.R-project.org')
#library(packfor)

##多元线性回归示例

#数据“fish_data.txt”来自前文：https://mp.weixin.qq.com/s/OIKHF74ANmbdwdu_-JCOjA
#读取鱼类物种丰度和水体环境数据
dat <- read.delim('fish_data.txt', sep = '\t', row.names = 1)

#本示例使用全部环境变量拟合与鱼类物种丰度的多元线性回归
fit_lm <- lm(fish~acre+do2+depth+no3+so4+temp, data = dat)
summary(fit_lm)  #展示拟合模型的概要

##使用 packfor 包中的函数进行前向选择，评估多元线性回归中各环境变量的 R2 贡献，获得重要的影响鱼类物种丰度的环境变量
library(packfor)

#packfor 包提供了两个函数
#forward.sel.par() 基于参数的方法，通过 F 检验评估 R2 的显著性，详情 ?forward.sel.par
#forward.sel() 基于非参数的方法，通过置换检验的原理评估 R2 的显著性，详情 ?forward.sel
forward.sel.par(Y = dat[c('fish')], X = dat[c('acre', 'do2', 'depth', 'no3', 'so4', 'temp')],
    R2more = 0.01, alpha = 0.05)
forward.sel(Y = dat[c('fish')], X = dat[c('acre', 'do2', 'depth', 'no3', 'so4', 'temp')], 
    R2more = 0.01, alpha = 0.05, nperm = 999)

#上述主要参数：
#Y 为响应变量矩阵，当 Y 是单变量时，意为在多元线性回归中进行前向选择；X 为预测变量矩阵
#R2more 为 R2 参数，如果前向选择过程中，新纳入一个变量后 R2 的累计贡献小于预设值（例如这里 0.01），前向选择将停止
#alpha 为 p 值的参数，如果前向选择过程中，新纳入一个变量后，p 值高于显著性阈值（例如这里 0.05），前向选择将停止
#nperm 仅在 forward.sel() 中适用，意为置换检验过程中的随机置换次数，用于估计 p 值

#备注：如果想查看所有变量的 R2 贡献和 p 值，可设置 alpha=1 和 R2more=0


##RDA 示例
library(vegan)

#数据“phylum_table.txt”和“env_table.txt”来自前文：https://mp.weixin.qq.com/s/pR_ZuGIjXzqg22Drdstc4w
#读取群落与环境变量
phylum <- read.delim('phylum_table.txt', row.names = 1, sep = '\t')
env <- read.delim('env_table.txt', row.names = 1, sep = '\t')

#物种数据 Hellinger 预转化（处理包含很多 0 值的群落物种数据时，推荐使用）
phylum_hel <- decostand(phylum, method = 'hellinger')
 
#使用全部的环境数据的 RDA
rda_tb <- rda(phylum_hel~., env, scale = FALSE)

#查看统计结果信息，以 I 型标尺为例
rda_tb.scaling1 <- summary(rda_tb, scaling = 1)
rda_tb.scaling1

##使用 packfor 包中的函数进行前向选择，评估 RDA 中各环境变量的 R2 贡献，获得重要的影响群落组成的环境变量
library(packfor)

#类似上文的多元回归过程
#Y 为响应变量矩阵，此时 Y 是一个多元矩阵，意为在 RDA 中进行前向选择；X 为预测变量矩阵
#R2more 为 R2 参数，如果前向选择过程中，新纳入一个变量后 R2 的累计贡献小于预设值（例如这里 0.01），前向选择将停止
#alpha 为 p 值的参数，如果前向选择过程中，新纳入一个变量后，p 值高于显著性阈值（例如这里 0.05），前向选择将停止
#这里仅以 forward.sel() 的非参数的方法为例，通过置换检验的原理评估 R2 的显著性，nperm 意为置换检验过程中的随机置换次数，用于估计 p 值
forward.sel(Y = phylum_hel, X = env, R2more = 0.01, alpha = 0.05, nperm = 999)

#类似地，如果想查看所有变量的 R2 贡献和 p 值，可设置 alpha=1 和 R2more=0
