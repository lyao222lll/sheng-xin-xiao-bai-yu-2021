#读取 OTUs 丰度表
otu <- read.delim('otu_select10.txt', check.names = FALSE, stringsAsFactors = FALSE)

#由于各 OTU 丰度之间差异巨大，对丰度作个标准化处理
otu[2:ncol(otu)] <- scale(otu[2:ncol(otu)], center = FALSE)

#转换为 ggplot2 的作图格式（就是那种“长数据框的格式”）
otu <- reshape2::melt(otu, id = 'plant_age')
head(otu)

#加载 R 包
library(ggplot2)
library(ggridges)

#绘制山峦图，详情 ?geom_ridgeline_gradient
#横坐标植物生长时间，纵坐标细菌 OTU，面积折线展示了各 OTU 标准化后的丰度
ggplot(otu, aes(x = plant_age, y = variable, height = value))  +
geom_ridgeline_gradient(scale = 0.5) +
labs(x = 'Plant Age (Days)', y = 'Age Discriminant OTUs') +
theme_ridges(font_size = 12, grid = TRUE, center_axis_labels = TRUE) +
scale_x_continuous(expand = c(0, 0))

#继续仿照上文文献中那样，随植物生长发育，丰度逐渐增加的 OTU 为黄色，丰度逐渐降低的 OTU 为蓝色

#读取分组数据
type <- read.delim('otu_type.txt', check.names = FALSE, stringsAsFactors = FALSE)

#合并到作图数据
otu <- merge(otu, type, by = 'variable')

#绘制山峦图，详情 ?geom_ridgeline_gradient
#横坐标植物生长时间，纵坐标细菌 OTU，面积折线展示了各 OTU 标准化后的丰度，并按丰度上升（up）或下降（down）的趋势标记颜色
ggplot(otu, aes(x = plant_age, y = variable, height = value, fill = type))  +
geom_ridgeline_gradient(scale = 0.5, color = 'white', show.legend = FALSE) +  
scale_fill_manual(values = c('#FFD700', '#1C8FFF'), limits = c('up', 'down')) +
labs(x = 'Plant Age (Days)', y = 'Age Discriminant OTUs') +
theme_ridges(font_size = 12, grid = TRUE, center_axis_labels = TRUE) +
scale_x_continuous(expand = c(0, 0))

