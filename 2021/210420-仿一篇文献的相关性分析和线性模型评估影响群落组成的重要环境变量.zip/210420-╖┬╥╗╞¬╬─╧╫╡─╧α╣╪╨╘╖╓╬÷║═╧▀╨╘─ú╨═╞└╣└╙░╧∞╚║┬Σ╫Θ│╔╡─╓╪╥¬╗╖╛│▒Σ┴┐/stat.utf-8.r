#读取环境变量和物种丰度矩阵
env <- read.delim('env_table.txt', sep = '\t', row.names = 1)
spe <- read.delim('spe_table.txt', sep = '\t', row.names = 1)
spe <- spe[rownames(env), ]

####环境变量和物种丰度的相关性分析
library(psych)
library(reshape2)

#可通过 psych 包函数 corr.test() 执行
#这里以 spearman 相关系数为例，暂且没对 p 值进行任何校正（可以通过 adjust 参数额外指定 p 值校正方法）
spearman <- corr.test(env, spe, method = 'spearman', adjust = 'none')
r <- data.frame(spearman$r)  #spearman 相关系数矩阵
p <- data.frame(spearman$p)  #p 值矩阵

#结果整理以便于作图
r$env <- rownames(r)
p$env <- rownames(p)
r <- melt(r, id = 'env')
p <- melt(p, id = 'env')
spearman <- cbind(r, p$value)
colnames(spearman) <- c('env', 'spe', 'spearman_correlation', 'p.value')
spearman$spe <- factor(spearman$spe, levels = colnames(spe))
head(spearman)  #整理好的环境变量和物种丰度的 spearman 相关性统计表

#ggplot2 作图，绘制环境变量和物种丰度的 spearman 相关性热图
library(ggplot2)

p1 <- ggplot() +
geom_tile(data = spearman, aes(x = spe, y = env, fill = spearman_correlation)) +
scale_fill_gradientn(colors = c('#2D6DB1', 'white', '#DC1623'), limit = c(-1, 1)) +
theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black'), legend.key = element_blank(), 
    axis.text.x = element_text(color = 'black', angle = 45, hjust = 1, vjust = 1), axis.text.y = element_text(color = 'black'), axis.ticks = element_line(color = 'black')) +
scale_x_discrete(expand = c(0, 0)) +
scale_y_discrete(expand = c(0, 0)) +
labs(y = '', x = '', fill = 'Correlation')

p1

#如果想把 spearman 相关系数的显著性也标记在图中，参考如下操作
spearman[which(spearman$p.value<0.001),'sig'] <- '***'
spearman[which(spearman$p.value<0.01 & spearman$p.value>0.001),'sig'] <- '**'
spearman[which(spearman$p.value<0.05 & spearman$p.value>0.01),'sig'] <- '*'
head(spearman)  #整理好的环境变量和物种丰度的 spearman 相关性统计表

p2 <- p1 +
geom_text(data = spearman, aes(x = spe, y = env, label = sig), size = 3)

p2

####环境变量和物种丰度的多元线性回归和方差分解
library(relaimpo)
library(packfor)

##如果想通过前向选择选择重要的环境变量

#未使用循环批处理每个环境和物种的关系，中间老出问题，还是手动一个个计算整理更好，至少不会出错......
#例如以环境变量和“Proteobacteria”的回归为例
spe_name <- 'Proteobacteria'

#变量选择，例如通过 packfor 包 forward.sel() 执行前向选择，以减少环境变量、降低共线性，并尽量保证解释率
#详情 ?forward.sel，有些细节参数可能需要视情况调整
set.seed(123)
forward_select <- forward.sel(Y = spe[spe_name], X = env, R2more = 0.01, alpha = 0.05, nperm = 999)

#基于上述前向选择的环境变量，使用 lm()拟合环境变量与各物种丰度的多元线性回归，获取最优模型
env_spe <- cbind(env[forward_select$variables], spe[spe_name])
colnames(env_spe)[ncol(env_spe)] <- 'spe'
fit_simple <- lm(spe~., data = env_spe)

lm_stat <- summary(fit_simple)
lm_stat$r.squared  #提取回归的原始 R2
lm_stat$adj.r.squared  #提取回归的校正后的 R2
F <- lm_stat$fstatistic
pf(F[1], F[2], F[3], lower.tail = FALSE)  #获取回归的 p 值

#使用 relaimpo 包 calc.relimp()，求多元线性回归（已通过变量选择后的最优模型）中各环境变量的相对重要性
#详情 ?calc.relimp，有些细节参数可能需要视情况调整，本示例仅使用默认值
crf <- calc.relimp(fit_simple, rela = FALSE)
crf$lmg

#如此方法，依次手动计算每一个物种的
#最后将获取的回归 R2、p 值等手动整理到表格中，如网盘附件“lm_result.forward.txt”所示
#将计算的变量的重要性指数等手动整理到表格中，如网盘附件“env_importance.forward.txt”所示

#读取上述整理好的包含回归 R2、p 值、变量的重要性指数等信息的数据表格
lm_result <- read.delim('lm_result.forward.txt', sep = '\t')
lm_result$spe <- factor(lm_result$spe, levels = colnames(spe))

env_importance <- read.delim('env_importance.forward.txt', sep = '\t')
env_importance <- melt(env_importance, id = 'env')
colnames(env_importance) <- c('env', 'spe', 'importance')

#绘制环境变量和物种丰度的线性回归的 R2 的柱形图
#这里以校正前的原始 R2 为例，您也可以绘制为校正后的 R2
p3 <- ggplot() +
geom_col(data = lm_result, aes(x = spe, y = r.squared*100), fill = '#4882B2', width = 0.6) +
theme(panel.grid = element_blank(), panel.background = element_blank(), 
    axis.text.x = element_text(color = 'black', angle = 45, hjust = 1, vjust = 1), axis.text.y = element_text(color = 'black'), 
    axis.line = element_line(color = 'black'),axis.ticks = element_line(color = 'black')) +
scale_y_continuous(expand = c(0, 0), limits = c(0, 100)) +
labs(y = 'Explained variation (%)', x = '')

p3

#如果想把线性回归的显著性也标记在图中，参考如下操作
lm_result[which(lm_result$p.value<0.001),'sig'] <- '***'
lm_result[which(lm_result$p.value<0.01 & lm_result$p.value>0.001),'sig'] <- '**'
lm_result[which(lm_result$p.value<0.05 & lm_result$p.value>0.01),'sig'] <- '*'

p4 <- p3 +
geom_text(data = lm_result, aes(x = spe, y = r.squared*100 + 5, label = sig), size = 3)

p4

#将多元线性回归中各环境变量的相对重要性以空心圈的形式添加在上文热图里面
p1 +
geom_point(data = env_importance, aes(x = spe, y = env, size = importance*100), shape = 1) +
scale_size_continuous(range = c(0, 5)) +
labs(size = 'Importance (%)')

p2 +
geom_point(data = env_importance, aes(x = spe, y = env, size = importance*100), shape = 1) +
scale_size_continuous(range = c(0, 5)) +
labs(size = 'Importance (%)')

#最后，在 AI 里面手动将热图和柱形图组合起来

####环境变量和物种丰度的多元线性回归和方差分解
library(relaimpo)
library(MASS)

##如果想通过后向选择选择重要的环境变量

#未使用循环批处理每个环境和物种的关系，中间老出问题，还是手动一个个计算整理更好，至少不会出错......
#例如以环境变量和“Proteobacteria”的回归为例
spe_name <- 'Proteobacteria'
env_spe <- cbind(env, spe[spe_name])
colnames(env_spe)[ncol(env_spe)] <- 'spe'

#使用 lm()，分别拟合所有环境变量与“Proteobacteria”丰度的多元线性回归
fit <- lm(spe~., data = env_spe)

#变量选择，例如通过 MASS 包 stepAIC() 执行后向选择，以减少环境变量、降低共线性，并尽量保证解释率，获取最优模型
#详情 ?stepAIC，有些细节参数可能需要视情况调整，本示例仅使用默认值
fit_simple <- stepAIC(fit, direction = 'backward')
lm_stat <- summary(fit_simple)

lm_stat$r.squared  #提取回归的原始 R2
lm_stat$adj.r.squared  #提取回归的校正后的 R2
F <- lm_stat$fstatistic
pf(F[1], F[2], F[3], lower.tail = FALSE)  #获取回归的 p 值

#使用 relaimpo 包 calc.relimp()，求多元线性回归（已通过变量选择后的最优模型）中各环境变量的相对重要性
#详情 ?calc.relimp，有些细节参数可能需要视情况调整，本示例仅使用默认值
crf <- calc.relimp(fit_simple, rela = FALSE)
crf$lmg

#如此方法，依次手动计算每一个物种的
#最后将获取的回归 R2、p 值等手动整理到表格中，如网盘附件“lm_result.backward.txt”所示
#将计算的变量的重要性指数等手动整理到表格中，如网盘附件“env_importance.backward.txt”所示

#读取上述整理好的包含回归 R2、p 值、变量的重要性指数等信息的数据表格
lm_result <- read.delim('lm_result.backward.txt', sep = '\t')
lm_result$spe <- factor(lm_result$spe, levels = colnames(spe))

env_importance <- read.delim('env_importance.backward.txt', sep = '\t')
env_importance <- melt(env_importance, id = 'env')
colnames(env_importance) <- c('env', 'spe', 'importance')

#绘制环境变量和物种丰度的线性回归的 R2 的柱形图
#这里以校正前的原始 R2 为例，您也可以绘制为校正后的 R2
p3 <- ggplot() +
geom_col(data = lm_result, aes(x = spe, y = r.squared*100), fill = '#4882B2', width = 0.6) +
theme(panel.grid = element_blank(), panel.background = element_blank(), 
    axis.text.x = element_text(color = 'black', angle = 45, hjust = 1, vjust = 1), axis.text.y = element_text(color = 'black'), 
    axis.line = element_line(color = 'black'),axis.ticks = element_line(color = 'black')) +
scale_y_continuous(expand = c(0, 0), limits = c(0, 100)) +
labs(y = 'Explained variation (%)', x = '')

p3

#如果想把线性回归的显著性也标记在图中，参考如下操作
lm_result[which(lm_result$p.value<0.001),'sig'] <- '***'
lm_result[which(lm_result$p.value<0.01 & lm_result$p.value>0.001),'sig'] <- '**'
lm_result[which(lm_result$p.value<0.05 & lm_result$p.value>0.01),'sig'] <- '*'

p4 <- p3 +
geom_text(data = lm_result, aes(x = spe, y = r.squared*100 + 5, label = sig), size = 3)

p4

#将多元线性回归中各环境变量的相对重要性以空心圈的形式添加在上文热图里面
p1 +
geom_point(data = env_importance, aes(x = spe, y = env, size = importance*100), shape = 1) +
scale_size_continuous(range = c(0, 5)) +
labs(size = 'Importance (%)')

p2 +
geom_point(data = env_importance, aes(x = spe, y = env, size = importance*100), shape = 1) +
scale_size_continuous(range = c(0, 5)) +
labs(size = 'Importance (%)')

#最后，在 AI 里面手动将热图和柱形图组合起来
