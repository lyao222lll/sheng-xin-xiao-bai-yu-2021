#数据来自前文：https://mp.weixin.qq.com/s/kz_BCYySYQbKgp8EGaqfLQ

##读入文件
#OTU 丰度表
otu <- read.delim('otu_table.txt', row.names = 1, sep = '\t')
otu <- data.frame(t(otu))

#样本分组文件
group <- read.delim('group.txt', sep = '\t', stringsAsFactors = TRUE)

##使用 vegan 包执行所有分组间的 PERMANOVA 分析，即整体差异
library(vegan)

#详情 ?adonis
#例如，相异指数以 Bray-Curtis 为例，并基于 999 次置换估计 p 值
set.seed(123)
adonis_result <- adonis(otu~site, group, distance = 'bray', permutations = 999)
adonis_result

#可选输出
#otuput <- data.frame(adonis_result$aov.tab, check.names = FALSE, stringsAsFactors = FALSE)
#otuput <- cbind(rownames(otuput), otuput)
#names(otuput) <- c('', 'Df', 'Sums of squares', 'Mean squares', 'F.Model', 'Variation (R2)', 'Pr (>F)')
#write.table(otuput, file = 'PERMANOVA.result_all.txt', row.names = FALSE, sep = '\t', quote = FALSE, na = '')

##使用 EcolUtils 包执行事后两两分组的 PERMANOVA 比较

#安装 EcolUtils 包：https://rdrr.io/github/GuillemSalazar/EcolUtils/f/README.md
#install.packages('devtools')
#devtools::install_github('GuillemSalazar/EcolUtils')
library(EcolUtils)

#首先计算相异指数，以 Bray-Curtis 为例
dis_bray <- vegdist(otu, method = 'bray')

#两两分组的 PERMANOVA 分析，详情 ?adonis.pair
#例如，基于 999 次置换估计 p 值，使用 fdr 校正 p 值
set.seed(123)
result1 <- adonis.pair(dist.mat = dis_bray, Factor = group$site, nper = 1000, corr.method = 'fdr')
result1

#输出表格至本地
#write.csv(result1, 'EcolUtils.adonis_pairwise.csv', row.names = FALSE, quote = FALSE)


##使用 metagMisc 包执行事后两两分组的 PERMANOVA 比较

#安装 metagMisc 包：https://rdrr.io/github/vmikk/metagMisc/f/README.md
#install.packages('devtools')
#devtools::install_github('vmikk/metagMisc')
library(metagMisc)

#首先计算相异指数，以 Bray-Curtis 为例
dis_bray <- vegdist(otu, method = 'bray')

#两两分组的 PERMANOVA 分析，详情 ?adonis_pairwise
#例如，基于 999 次置换估计 p 值，使用 fdr 校正 p 值
set.seed(123)
result2 <- adonis_pairwise(x = group, group.var = 'site', dd = dis_bray, permut = 999, p.adj = TRUE, adj.meth = 'fdr')
result2

result2$Adonis.tab  #统计表概要
result2$Adonis  #两两比较的细节部分

#输出
#write.csv(result2$Adonis.tab, 'metagMisc.adonis_pairwise.csv', row.names = FALSE, quote = FALSE)


##使用 pairwiseAdonis 包执行事后两两分组的 PERMANOVA 比较

#安装 pairwiseAdonis 包：https://github.com/pmartinezarbizu/pairwiseAdonis
#install.packages('devtools')
#devtools::install_github('pmartinezarbizu/pairwiseAdonis/pairwiseAdonis')
library(pairwiseAdonis)

#两两分组的 PERMANOVA 分析，详情 ?pairwise.adonis
#例如，相异指数以 Bray-Curtis 为例，并基于 999 次置换估计 p 值，使用 fdr 校正 p 值
set.seed(123)
result3 <- pairwise.adonis(x = otu, factors = group$site, sim.method = 'bray', perm = 999, p.adjust.m = 'fdr')
result3

#输出
#write.csv(result3, 'pairwiseAdonis.adonis_pairwise.csv', row.names = FALSE, quote = FALSE)


