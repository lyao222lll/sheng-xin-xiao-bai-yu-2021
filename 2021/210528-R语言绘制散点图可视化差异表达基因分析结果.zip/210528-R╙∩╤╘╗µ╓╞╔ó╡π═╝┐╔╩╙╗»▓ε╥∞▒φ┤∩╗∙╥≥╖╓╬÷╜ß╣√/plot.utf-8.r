library(ggplot2)

#读取示例数据
express <- read.delim('gene_diff.txt', sep = '\t')

#绘制散点图，将差异基因和非差异基因以不同颜色区分
#x 轴和 y 轴分别代表了基因在两组数据中标准化后的均值
ggplot(express, aes(x = group1_mean, y = group2_mean)) +
geom_point(aes(color = sig), size = 1)

##
#将基因表达值取个 log10(1+) 转换（因为有些 0 值无法对数转换，+1 后就可以了）
express$log10_group1_mean <- log(express$group1_mean+1, 10)
express$log10_group2_mean <- log(express$group2_mean+1, 10)
head(express)  #可以看到在表格中增添了 log10 转换后的两列数据，后续用这两列数据作图

#绘制散点图，将差异基因和非差异基因以不同颜色区分
#x 轴和 y 轴分别代表了基因在两组数据中经过 log10 转换后的均值
ggplot(express, aes(x = log10_group1_mean, y = log10_group2_mean)) +
geom_point(aes(color = sig), size = 1) 

##
#可选对基因按差异状态排个序，目的是将差异基因展示在前方图层，避免被非差异基因的点遮盖
express$sig <- factor(express$sig, levels = c('group1 high', 'group2 high', 'no diff'))
express <- express[order(express$sig, decreasing = TRUE), ]

#绘制散点图，将差异基因和非差异基因以不同颜色区分
#x 轴和 y 轴分别代表了基因在两组数据中经过 log10 转换后的均值
ggplot(express, aes(x = log10_group1_mean, y = log10_group2_mean)) +
geom_point(aes(color = sig), size = 1)

####绘制差异基因散点图，颜色表示不同组的差异基因

#完善其它细节，例如
p1 <- ggplot(express, aes(x = log10_group1_mean, y = log10_group2_mean)) +
geom_point(aes(color = sig), size = 1) +  #按差异基因状态指定基因点的颜色
scale_color_manual(values = c('red', 'blue', 'gray'), limit = c('group1 high', 'group2 high', 'no diff')) +  #自定义赋值基因颜色
theme(panel.grid.major = element_blank(), 
    panel.background = element_rect(color = 'black', fill = 'transparent'), 
    legend.key = element_rect(fill = 'transparent'), legend.background = element_blank(), 
    axis.ticks = element_line(size = 0.4)) +  #主题调整，线框、底色、图例等
scale_x_continuous(breaks = 0:5, limits = c(0, 5),  #以下两句调整坐标轴字体，修改成为带指数的上标形式
    labels = c(expression(10^{0}), expression(10^{1}), expression(10^{2}), expression(10^{3}), expression(10^{4}), expression(10^{5}))) +
scale_y_continuous(breaks = 0:5, limits = c(0, 5), 
    labels = c(expression(10^{0}), expression(10^{1}), expression(10^{23}), expression(10^{3}), expression(10^{4}), expression(10^{5}))) +
labs(x = 'Mean of Normalized Abundance (group1)', y = 'Mean of Normalized Abundance (group2)', color = '')  #坐标轴标题设置

p1

#已知示例的数据表中，差异基因是根据 p<0.01 以及 |log2 Fold Change|>1 的标准筛选的
#期望在图中添加 |log2FC|>1 的阈值线
p1 <- p1 + geom_abline(intercept = 1, slope = 1, col = 'black', linetype = 'dashed', size = 0.5) +
geom_abline(intercept = -1, slope = 1, col = 'black', linetype = 'dashed', size = 0.5) +
geom_abline(intercept = 0, slope = 1, col = 'black', linetype = 'dashed', size = 0.5)

p1

####绘制差异基因散点图，颜色表示统计检验的 p 值

#按 p 值数值的渐变色散点图
#本示例除了颜色赋值方式外，其余细节调整同上文
p2 <- ggplot(express, aes(x = log10_group1_mean, y = log10_group2_mean)) +
geom_point(aes(color = pvalue), size = 0.8) +  #按 p 值大小指定基因点的颜色
scale_color_gradientn(colors = c('#B90400', '#FF9700', '#FFE000', '#DBF750', 
    '#C8F963', '#12FFAF', '#4DACDF', '#0755DF', '#022AA7', '#00239F')) +  #渐变色颜色指定
theme(panel.grid.major = element_blank(), 
    panel.background = element_rect(color = 'black', fill = 'transparent'), 
    legend.key = element_rect(fill = 'transparent'), legend.background = element_blank(), 
    axis.ticks = element_line(size = 0.4)) +  #主题调整，线框、底色、图例等
scale_x_continuous(breaks = 0:5, limits = c(0, 5),  #以下两句调整坐标轴字体，修改成为带指数的上标形式
    labels = c(expression(10^{0}), expression(10^{1}), expression(10^{2}), expression(10^{3}), expression(10^{4}), expression(10^{5}))) +
scale_y_continuous(breaks = 0:5, limits = c(0, 5), 
    labels = c(expression(10^{0}), expression(10^{1}), expression(10^{23}), expression(10^{3}), expression(10^{4}), expression(10^{5}))) +
labs(x = 'Mean of Normalized Abundance (group1)', y = 'Mean of Normalized Abundance (group2)', color = 'P value') +  #坐标轴标题设置
geom_abline(intercept = 1, slope = 1, col = 'black', linetype = 'dashed', size = 0.5) +  #这 3 句用于添加 |log2FC|>1 的阈值线
geom_abline(intercept = -1, slope = 1, col = 'black', linetype = 'dashed', size = 0.5) +
geom_abline(intercept = 0, slope = 1, col = 'black', linetype = 'dashed', size = 0.5)

p2

####如若添加基因名称

#读取准备好的基因列表，例如这里根据 p 值提前筛选出了 top10 重要的基因
select_gene <- read.delim('top10_gene.txt', sep = '\t')

#根据共同的“gene_id”，从作图数据中匹配这些基因的作图信息
select_gene <- merge(select_gene, express, by = 'gene_id', all.x = TRUE)
head(select_gene)

#将基因名称添加在上文已绘制好的图中
library(ggrepel)

p1 + 
geom_text_repel(data = select_gene, aes(x = log10_group1_mean, y = log10_group2_mean, label = gene_name),
    size = 3, box.padding = unit(0.6, 'lines'), segment.color = 'black', show.legend = FALSE)

p2 + 
geom_label_repel(data = select_gene, aes(x = log10_group1_mean, y = log10_group2_mean, label = gene_name), 
    size = 3, box.padding = unit(0.6, 'lines'), segment.color = 'black', show.legend = FALSE)

####散点的颜色表示其它信息

#读取示例数据
noiseq <- read.delim('NOISeq.result.select_diff.txt', sep = '\t')

#将基因表达值取个 log10(1+) 转换（因为有些 0 值无法对数转换，+1 后就可以了）
noiseq$log10_Kidney_mean <- log(noiseq$Kidney_mean+1, 10)
noiseq$log10_Liver_mean <- log(noiseq$Liver_mean+1, 10)
	
#可选对基因按差异状态排个序，目的是将差异基因展示在前方图层，避免被非差异基因的点遮盖
noiseq$diff <- factor(noiseq$diff, levels = c('Kidney high', 'Liver high', 'no diff'))
noiseq <- noiseq[order(noiseq$diff, decreasing = TRUE), ]

#按 probability 值数值的渐变色散点图
#本示例除了颜色赋值方式外，其余细节调整同上文
library(ggplot2)

p3 <- ggplot(noiseq, aes(x = log10_Kidney_mean, y = log10_Liver_mean)) +
geom_point(aes(color = prob), size = 0.8) +  #按 probability 值大小指定基因点的颜色
scale_color_gradient2(low = 'royalblue2', mid = 'green', high = 'red', midpoint = 0.5) +  #渐变色颜色指定
theme(panel.grid.major = element_blank(), plot.title = element_text(hjust = 0.5), 
    panel.background = element_rect(color = 'black', fill = 'transparent'), 
    legend.key = element_rect(fill = 'transparent'), legend.background = element_blank(), 
    axis.ticks = element_line(size = 0.4)) +  #主题调整，线框、底色、图例等
scale_x_continuous(breaks = 0:5, limits = c(0, 5),  #以下两句调整坐标轴字体，修改成为带指数的上标形式
    labels = c(expression(10^{0}), expression(10^{1}), expression(10^{2}), expression(10^{3}), expression(10^{4}), expression(10^{5}))) +
scale_y_continuous(breaks = 0:5, limits = c(0, 5), 
    labels = c(expression(10^{0}), expression(10^{1}), expression(10^{23}), expression(10^{3}), expression(10^{4}), expression(10^{5}))) +
labs(x = '\nMean of Normalized Abundance (Kidney)', y = 'Mean of Normalized Abundance (Liver)\n',  title = 'Kidney vs Liver\n', color = 'Probability') +  #坐标轴标题设置
geom_abline(intercept = 1, slope = 1, col = 'black', linetype = 'dashed', size = 0.5) +  #这 3 句用于添加 |log2FC|>1 的阈值线
geom_abline(intercept = -1, slope = 1, col = 'black', linetype = 'dashed', size = 0.5) +
geom_abline(intercept = 0, slope = 1, col = 'black', linetype = 'dashed', size = 0.5)

p3

