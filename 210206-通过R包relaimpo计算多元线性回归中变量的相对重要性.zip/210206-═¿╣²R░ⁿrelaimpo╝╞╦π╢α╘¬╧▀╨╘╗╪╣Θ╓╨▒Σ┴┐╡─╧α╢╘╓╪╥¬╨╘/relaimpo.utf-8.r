#读取鱼类物种丰度和水体环境数据
dat <- read.delim('fish_data.txt', sep = '\t', row.names = 1)

#先前的多元线性回归推文链接：https://mp.weixin.qq.com/s/HS6JgAjlHItqVpM-j3iNqw

#根据前文结果，最终只考虑使用 3 个和鱼类物种丰度线性关系较为明显的环境变量拟合多元线性回归
fit_lm <- lm(fish~acre+depth+no3, data = dat)
summary(fit_lm)  #展示拟合回归的简单统计


##使用 relaimpo 包评估变量的相对重要性
library(relaimpo)

#使用函数 calc.relimp() 评估模型中各个自变量的相对重要性，详情 ?calc.relimp
#可以将上述 lm() 拟合的多元线性回归模型直接输入到 calc.relimp()
crf <- calc.relimp(fit_lm, rela = TRUE, 
    type = c('lmg', 'last', 'first', 'betasq', 'pratt', 'genizi', 'car'))

#或者不套用 lm() 的结果，而是直接使用原始数据，并将公式书写在 calc.relimp() 中
crf <- calc.relimp(fish~acre+depth+no3, data = dat, rela = TRUE, 
    type = c('lmg', 'last', 'first', 'betasq', 'pratt', 'genizi', 'car'))

#特别备注：
#type 参数用于指定评估变量重要性的具体算法，这里指定了 7 种不同的方案（由不同学者提出），不同方法之间可能区别较大
#rela=T 时，相对重要性的总和被标准化为 100％，即各自变量对 R2 的贡献的总和被标准化为 100％；而当 rela=F 时不标准化，总和近似回归模型总 R2（本示例中，lm() 原模型的 R2 约为 28%）
#更多细节请参考帮助文档，?calc.relimp

#上述两种方式选哪种都可以，结果是一样的，现在查看结果
crf
plot(crf)
